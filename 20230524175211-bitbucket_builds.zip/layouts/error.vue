<template>
  <VApp>
    <VContent>
      <VContainer fluid>
        <VLayout
          justify-center fill-height
          column pa-5 class="text-xs-center"
        >
          <VFlex v-if="error.statusCode === 404" mb-5>
            <img
              src="~/assets/billy_not_found.svg" alt="bp-logo" height="180px"
            >
          </VFlex>
          <VFlex v-else mb-5>
            <img
              src="~/assets/errorpad.png" alt="bp-logo" height="180px"
            >
          </VFlex>

          <VFlex my-2>
            <p
              v-if="error.statusCode == 404 || error.errorCode == 404 || error.errorCode == 500"
              class="headline font-weight-bold blue-grey--text"
            >
              Ha ocurrido un problema
            </p>
            <p v-else class="headline font-weight-bold blue-grey--text">
              No se pudo realizar el pago
            </p>
          </VFlex>
          
          <VFlex my-4>
            <p v-if="error.message" class="title font-weight-medium">
              {{ error.message }}
              <span 
                v-if="error.errorCode" class="grey--text"
              > Error ({{ error.errorCode }})</span>
              <span 
                v-else class="grey--text"
              > Error ({{ error.statusCode }})</span>
            </p>
          </VFlex>
         
          <VFlex v-if="error.callbackUrl" my-3>
            <VBtn
              color="blue-grey" dark @click.native="redirect(error.callbackUrl)"
            >
              {{ error.callbackText || 'Volver' }}
            </VBtn>
          </VFlex>
          <VFlex v-if="error.redirectUrl" my-3>
            <VBtn
              color="blue-grey" dark @click.native="redirect(error.redirectUrl)"
            >
              {{ error.redirectText || 'Volver' }}
            </VBtn>
          </VFlex>
        </VLayout>
        
        <BPFooter class="mt-4" />
      </VContainer>
    </VContent>
  </VApp>
</template>

<script>
import BPFooter from '@/components/shared/BPFooter.vue'

export default {
    components: {
        BPFooter
    },
    props: {
        error: {
            type: Object,
            default: null
        }
    }, 
    methods: {
        redirect( url ){
            window.location.href=url;
        }
    }
}
</script>
