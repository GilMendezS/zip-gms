<template>
  <VApp>
    <VContent>
      <VContainer fluid>
        <nuxt />
      </VContainer>
    </VContent>
  </VApp>
</template>

<style >
.theme--light.application{
  background-color: #F9FCFF;
}
</style>
