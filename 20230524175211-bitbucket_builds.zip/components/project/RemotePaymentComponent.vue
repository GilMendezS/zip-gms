<template>
  <VFlex mt-4>
    <VLayout
      align-center justify-center
      row fill-height
    >
      <VFlex
        xl10 md11
        sm12
      >
        <div v-html="htmlEntity" />

        <VCard>
          <div class="pa-2" :style="`background-color: ${color}`" />

          <VLayout
            row wrap
            justify-center pa-4 mt-2
          >
            <VFlex
              md4 sm12
              px-2
            >
              <div class="box">
                <div>
                  <p class="text-xs-center text-md-left">
                    {{ externalId }}
                  </p>
                  <p class="text-xs-center text-md-left">
                    {{ extra.merchantDescription }}
                  </p>
                </div>
              </div>
              <p class="rp-subheader mb-1 mt-4 text-xs-center text-md-left">
                Mensaje:
              </p>
              <p class="mb-4 text-xs-center text-md-left">
                {{ description }}
              </p>
              <p class="rp-subheader remove-spacing text-xs-center text-md-left">
                Total a enviar (MXN)
              </p>
              <p class="price-sign">
                <span class="text-grey text-xs-center text-md-left">$</span>
                <span class="price-text text-xs-center text-md-left">{{ fixedValue }}</span>
              </p>
            </VFlex>

            <VFlex
              md8 sm12
              px-3
            >
              <p class="title text-xs-center text-md-left">
                Método de pago
              </p>
              <no-ssr v-if="clickToPayIsEnabled">
                <VLayout>
                  <VFlex>
                    <input
                      v-model="paymentTypeSelected" type="radio"
                      value="default"
                    > Tarjeta de débito o crédito
                    <input
                      v-model="paymentTypeSelected" type="radio"
                      value="c2p"
                    >
                    <src-button
                      height="40"
                      width="200"
                      name="c2pbtn"
                      theme="light"
                      card-brands="['mastercard', 'visa', 'amex']"
                    />
                  </VFlex>
                </VLayout>
              </no-ssr>
              <VForm
                ref="paywithForm"
                class="my-5"
                @submit.prevent="sendInformation"
              >
                <VLayout
                  row wrap
                  my-3
                >
                  <VFlex px-1>
                    <no-ssr>
                      <div id="c2pCardListDiv">
                        <src-card-list
                          id="srcCardList" locale="es_MX"
                          card-brands="" display-cancel-option="false" display-add-card="false"
                          card-selection-type="radioButton" src-digital-card-id="" display-header="false"
                        />
                      </div>
                    </no-ssr>
                  </VFlex>
                </VLayout>
                <div v-show="paymentTypeSelected === 'default'">
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        E-mail
                      </p>
                      <VTextField
                        id="useremail"
                        v-model.trim="clientData.email"
                        name="useremail"
                        autocomplete="email"
                        placeholder="E-mail"
                        prepend-inner-icon="email"
                        :color="color"
                        :rules="rules.emailRules"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Teléfono
                      </p>
                      <VTextField
                        id="userphone"
                        v-model.trim="clientData.phone"
                        name="userphone"
                        placeholder="Teléfono"
                        prepend-inner-icon="phone"
                        mask="##########"
                        :color="color"
                        :rules="[rules.phoneRules]"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Nombre(s)
                      </p>
                      <VTextField
                        id="name"
                        v-model.trim="clientData.name"
                        name="name"
                        autocomplete="name"
                        placeholder="Nombre completo"
                        prepend-inner-icon="person"
                        :color="color"
                        :rules="[rules.required, rules.strings]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Apellidos
                      </p>
                      <VTextField
                        id="lastname"
                        v-model.trim="clientData.lastname"
                        name="lastname"
                        placeholder="Apellidos"
                        prepend-inner-icon="person"
                        :color="color"
                        :rules="[rules.required, rules.strings]"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Número de tarjeta
                      </p>
                      <VTextField
                        id="card"
                        v-model.trim="clientData.card"
                        name="card"
                        autocomplete="cc-number"
                        :placeholder="placeholderCard"
                        prepend-inner-icon="credit_card"
                        :mask="cardDigits"
                        :color="color"
                        :rules="[rules.required, rules.isValidCard]"
                        @blur="onBlur"
                      />
                      <span v-show="amexAmountExceeded || internationalCardAmountExceeded" class="red--text">
                        {{ getIssuerAmountExceeded }}
                      </span>
                      <VAlert
                        :value="showCustomBanner"
                        color="blue"
                        icon="info"
                        outline
                      >
                        Garantiza mayor aprobación y seguridad pagando con tu Tarjeta Digital de la App BBVA.
                      </VAlert>
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Vigencia
                      </p>
                      <VTextField
                        id="period"
                        v-model.trim="clientData.period"
                        name="period"
                        autocomplete="cc-exp"
                        placeholder="MM/YY"
                        :color="color"
                        mask="##/##"
                        :rules="[rules.required, rules.isValidExpDate]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Código CVV
                      </p>
                      <VTextField
                        id="cvv"
                        v-model.trim="clientData.cvv"
                        name="cvv"
                        type="password"
                        autocomplete="cc-csc"
                        :placeholder="placeholderDigits"
                        :color="color"
                        :mask="cvvDigits"
                        append-outer-icon="help"
                        :rules="rules.isAmex"
                        @click:append-outer="cvvMessage = !cvvMessage"
                      />
                    </VFlex>
                  </VLayout>
                </div>
                <div v-if="cvvMessage">
                  <VLayout
                    align-center justify-center
                    row wrap px-3
                  >
                    <VFlex
                      xs12 sm3
                      class="text-xs-center text-sm-left"
                    >
                      <img
                        src="~/assets/credit-cardCVV.svg"
                        alt="credit_card"
                        height="45"
                      >
                    </VFlex>
                    <VFlex sm9 class="text-xs-center text-sm-left">
                      <p class="subheading blue-grey--text">
                        Es el código de 3 o 4 dígitos ubicado al reverso de la
                        tarjeta.
                      </p>
                    </VFlex>
                  </VLayout>
                </div>
                <VLayout
                  row wrap
                  my-3
                >
                  <VFlex>
                    <VCheckbox
                      v-show="!c2pCards" v-model="createC2p"
                      label="Crear cuenta Click to Pay"
                    />
                    <p class="subheading my-0 font-weight-medium">
                      Planes de pago
                    </p>
                    <p class="grey--text mb-0">
                      Hasta 24 mensualidades
                      <span
                        href="#"
                        class="blue--text showBanks"
                        @click="showBanks"
                      >
                        Ver tarjetas participantes
                      </span>
                    </p>
                    <VSelect
                      v-model="selectedMonth"
                      :items="monthsList"
                      :dense="true"
                      item-text="text"
                      item-value="month"
                      item-disabled="readonly"
                      @change="onChange"
                    />
                    <p 
                      v-if="userIsUsingPlan"
                      class="grey--text mt-0"
                    >
                      Monto total a pagar: ${{ fixedSubtotal }}
                    </p>
                  </VFlex>
                </VLayout>
                <div 
                  v-if="showAmexForm"
                >
                  <p class="help-amex">
                    American Express solicita los siguientes datos para proteger tu compra.
                  </p>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Correo
                      </p>
                      <VTextField
                        id="correo"
                        v-model.trim="clientData.email"
                        name="correo"
                        autocomplete="email"
                        :color="color"
                        :rules="rules.emailRules"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Teléfono
                      </p>
                      <VTextField
                        id="phone"
                        v-model.trim="clientData.phone"
                        name="phone"
                        :color="color"
                        mask="##########"
                        :rules="[rules.phoneRules]"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Código Postal
                      </p>
                      <VTextField
                        id="zipcode"
                        v-model.trim="clientData.zipcode"
                        name="zipcode"
                        mask="#####"
                        autocomplete="zipcode"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Colonia
                      </p>
                      <VTextField
                        id="neighborhood"
                        v-model.trim="clientData.neighborhood"
                        name="neighborhood"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Calle
                      </p>
                      <VTextField
                        id="street"
                        v-model.trim="clientData.street"
                        name="street"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Numero Exterior
                      </p>
                      <VTextField
                        id="address_1"
                        v-model.trim="clientData.address_1"
                        name="address_1"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Numero Interior
                      </p>
                      <VTextField
                        id="address_2"
                        v-model.trim="clientData.address_2"
                        name="address_2"
                        :color="color"
                      />
                    </VFlex>
                  </VLayout>
                </div>

                <VBtn
                  type="submit"
                  block
                  color="blue-grey darken-3"
                  :disabled="amexAmountExceeded || internationalCardAmountExceeded || makingApiCall"
                  class="white--text"
                >
                  Realizar pago
                </VBtn>
              </VForm>
            </VFlex>
          </VLayout>
        </VCard>
      </VFlex>
    </VLayout>
    <VDialog
      v-model="redirectDialog"
      persistent
      transition="dialog-transition"
      max-width="400px"
    >
      <VCard>
        <VCardText>
          <VLayout
            align-center justify-center
            column fill-height
          >
            <p class="subheading text-xs-center blue-grey--text darken-2">
              En 5 segundos, será redirigido para validar los datos de su
              tarjeta.
            </p>
            <VProgressLinear
              :indeterminate="true"
              :color="color"
              class="my-4"
            />

            <VBtn
              block
              color="blue-grey darken-3"
              dark
              outline
              @click.native="cancelRedirect"
            >
              Cancelar
            </VBtn>
          </VLayout>
        </VCardText>
      </VCard>
    </VDialog>
    <!-- modal for banks -->
    <VModalOfBanks :is-open="dialogForBanks" @closeModal="handlerCloseModal" />
  </VFlex>
</template>

<script>
/* eslint-disable no-useless-escape */
import luhn from 'luhn'
import validExpDate from '@/utils/valid.exp-date'
import cardMixin from '@/mixins/amex.mixin.js';
import amountMixin from '@/mixins/amount.mixin.js';
import click2Pay from '@/mixins/click2pay.mixin.js';
import ModalOfBanks from '@/components/project/ModalOfBanks.vue';

export default {
    name: 'RemotePaymentComponent',
    components: {
        'VModalOfBanks': ModalOfBanks,
    },
    mixins: [ cardMixin, amountMixin, click2Pay ],
    props: {
        color: { type: String, required: true },
        orderId: { type: String, required: true },
        externalId: { type: String, required: true },
        redirectUrl: { type: String, required: true },
        items: { type: Array, required: true },
        total: { type: String, required: true },
        serviceApi: { type: String, required: true },
        merchant: { type: String, default: '' },
        description: { type: String, default: '' },
        extra: { type: Object, required: true },
        excluded: { type: String, default: '' },
        plans: { type: Array, default: null },
        msiEnabled: { type: Boolean, default: false },
        amexMessage: { type: String, default: '' },
        amexLimit: { type: String, default: '' },
        unlimitedAmex: { type: Boolean, default: false },
        unlimitedInternationalCards: { type: Boolean, default: false },
        userId: { type: Number, default: null },
        siftBeaconKey: { type: String, default: '' },
        envs: { type: Object, required: true },
        ip: { type: String, default: '' },
    },
    data() {
        return {
            subtotal: '',
            formPayment: null,
            selectedMonth: 1,
            canApply: false,
            customLabel: 'Hasta 24 mensualidades',
            dialogForBanks: false,
            atLeastOneBlur: false,
            availablePLans: [],
            clientData: {
                name: '',
                lastname: '',
                card: '',
                period: '',
                cvv: '',
                payment_method: 1,
                newAmount: null,
                typeMonthlyPayment: '',
                email: '',
                phone: '',
            },
            cvvDigits: '####',
            placeholderDigits: '***',
            cardDigits: '#### - #### - #### - ####',
            placeholderCard: 'xxxx - xxxx - xxxx - xxxx',
            cvvMessage: false,
            showMSI: false,
            redirectDialog: false,
            redirectFlag: false,
            htmlEntity: null,
            redirectTo: '/success',
            rules: {
                required: true,
                strings: true,
                isValidCard: true,
                isValidExpDate: true,
                emailRules: [
                    v => true,
                    v => true
                ],
                basicPhone: true,
                phoneRules: true,
                amexDigits: [
                    v => true,
                ],
            },
            showCustomBanner: false,
            currentIssuer: '',
            makingApiCall: false,
            click2PayInstance: null,
            showC2PCardList: false,
            selectedView: '',
            paymentTypeSelected: 'default',
            createC2p: true,
            c2pCards: [],
            currentCardId: null,
        }
    },
    computed: {
        amexDigits() {
            let rules = [];
            const mainRule = v => true;
            rules = [ 
                mainRule,
            ];
            if ( this.isAmex ) {
                const rule = v => v ?  v.length === 4 || 'El cvv debe ser de 4 dígitos.' : '';
                rules.push( rule );
            }
            
            return rules;
        },
        isAmex() {
            if ( this.clientData.card && luhn.validate( this.clientData.card ) ) {
                if ( this.clientData.card.startsWith( '37' ) || this.clientData.card.startsWith( '34' ) ) {
                    return true;
                }
            }
            return false;
        },
        showAmexForm() {
            return this.clientData.card && this.isAmex && luhn.validate( this.clientData.card ); 
        },
        fixedValue () {
            return this.fixedDigits( this.total );
        },
        fixedSubtotal() {
            return this.fixedDigits( this.subtotal );
        },
        avoid3DSVerification() {
            if ( this.envs.status3dsPAD === 'disabled' ) {
                return true;
            }
            try {
                const bines = this.excluded;
                const binesAsArray = bines.split( ',' );
                if( this.clientData.card === null ) {
                    return false;
                }
                const binOfCard = this.clientData.card.substring( 0, 6 );
                if ( binesAsArray.includes( binOfCard ) ) {
                    return true;
                }
                return false;
            } catch( err ) {
                return false;
            }
            
        },
        monthsList() {
            const self = this;
            if ( !self.canApplyPaymentSchemas ) {
                return [
                    {
                        text: `1 pago de $${ this.total }`,
                        month: 1,
                        readonly: true,
                    }
                ];
            }
            if ( !self.atLeastOneBlur ) {
                return [
                    {
                        text: 'Introduce primero tu tarjeta',
                        month: 1,
                        readonly: true,
                    }
                ];
            }
            return this.plans.map( item => {
                const transformedAmount = this.getAmountWithCommas( item.amountPerMonth );
                const data =  {
                    text: `${ item.months  } ${ item.months > 1 ?
                        'pagos mensuales' :
                        'pago ' } de $${ transformedAmount }`,
                    month: item.months,
                  
                };
                if ( self.availablePLans.includes( item.months ) ) {
                    data.readonly = !self.canApply;
                } else {
                    data.readonly = true;
                    if ( item.months !== 1 ) {
                        data.text += ' (No disponible para tu tarjeta, consulta tarjetas participantes)';
                    }
                    
                }
                if ( item.months === 1 ) {
                    data.readonly = false;
                }
                return data;
            } );
        },
        floatAmount() {
            return parseFloat( this.total );
        },
        canApplyPaymentSchemas() {
            const minimumAmount = 300.0;
            return this.floatAmount >= minimumAmount;
        },
        userIsUsingPlan() {
            return this.selectedMonth > 1;
        },
        floatMaxAmountAmex(){
            return parseFloat( this.amexLimit );
        },
        floatMaxAmountInternationalCard() {
            return parseFloat( this.envs.LIMIT_FOR_INTERNATIONAL_CARDS );
        },
        amexAmountExceeded () {
            if ( this.unlimitedAmex ) {
                return false;
            }
            return ( this.isAmex || this.currentIssuer === 'BBVA' ) && this.floatAmount > this.floatMaxAmountAmex ;
        },
        internationalCardAmountExceeded() {
            if ( this.currentIssuer === 'INTERNATIONAL' && this.unlimitedInternationalCards ) {
                return false;
            }
            return this.currentIssuer === 'INTERNATIONAL' && this.floatAmount > this.envs.LIMIT_FOR_INTERNATIONAL_CARDS;
        },
        getIssuerAmountExceeded() {
            if ( this.currentIssuer === 'AMEX' ) {
                return this.getAmexMessageForExceededAmount;
            }
            else if ( this.currentIssuer === 'BBVA' ) {
                return this.getBBVAMessageForExceededAmount;
            }
            else if ( this.currentIssuer === 'INTERNATIONAL' ) {
                return this.getMessageForInternationalCards;
            }
            return '';
        },
        getAmexMessageForExceededAmount() {
            const messageToShow = this.amexMessage;
            return 'American Express ' + messageToShow.replace( '{amount}', this.floatMaxAmountAmex );
        },
        getBBVAMessageForExceededAmount() {
            const messageToShow = this.amexMessage;
            return 'BBVA ' + messageToShow.replace( '{amount}', this.floatMaxAmountAmex );
        },
        getMessageForInternationalCards() {
            const messageToShow = this.amexMessage;
            return 'Tarjetas emitidas fuera de México '
              + messageToShow.replace( '{amount}', this.envs.LIMIT_FOR_INTERNATIONAL_CARDS  );
        },
        clickToPayIsEnabled() {
            return this.envs.STATUS_C2P === 'enabled';
        },
        getInformationCardForC2P() {
            const card = this.c2pCards.find( item => item.srcDigitalCardId === this.currentCardId );
            return card;
        }
    },
    watch: {
        clientData: {
            deep: true,
            handler: function () {
                if ( this.clientData.card && 
                 ( this.clientData.card.startsWith( '37' ) || this.clientData.card.startsWith( '34' ) ) ){
                    this.cardDigits = '#### - ###### - #####';
                    this.placeholderDigits = '****';
                } else {
                    this.cardDigits = '#### - #### - #### - ####';
                    this.placeholderDigits = '***';
                }
            },
        }
    },
    async mounted() {
        const _user_id = this.userId.toString();
        const _sift = window._sift = window._sift || [];
        _sift.push( [ '_setAccount', this.siftBeaconKey ] );
        _sift.push( [ '_setUserId', _user_id ] );
        _sift.push( [ '_trackPageview' ] );

        ( function() {
            function ls() {
                const e = document.createElement( 'script' );
                e.src = 'https://cdn.sift.com/s.js';
                document.body.appendChild( e );
            }
            if ( window.attachEvent ) {
                window.attachEvent( 'onload', ls );
            } else {
                window.addEventListener( 'load', ls, false );
            }
        } )();
        const recaptchaScript = document.createElement( 'script' );
        recaptchaScript.async = true;
        recaptchaScript.defer = true;
        recaptchaScript.setAttribute( 'src', `https://www.google.com/recaptcha/api.js?render=${ this.envs.VUE_RECAPTCHA_KEY }` );
        document.head.appendChild( recaptchaScript );
        const googleTagManagerScript = document.createElement( 'script' );
        const googleTagManagerNoScript = document.createElement( 'noscript' );
        googleTagManagerScript.async = true;
        googleTagManagerNoScript.async = true;
        googleTagManagerScript.defer = true;
        googleTagManagerNoScript.defer = true;
        googleTagManagerScript.type = 'text/javascript';
        googleTagManagerNoScript.type = 'text/javascript';
        if ( this.envs.addTagManager ) {
            googleTagManagerScript.text = `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-PQLMWZD');`;
            googleTagManagerNoScript.text = `<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PQLMWZD"
height="0" width="0" style="display:none;visibility:hidden"></iframe>`;
        } else {
            googleTagManagerScript.text = "console.log('GTM must be added :D')";
        }
        document.head.appendChild( googleTagManagerScript );
        document.body.appendChild( googleTagManagerNoScript );
        try {
            const cards = await this.getCards( this.envs.SRC_APP_ID,
                this.envs.C2P_ALLOWED_BRANDS || [ 'mastercard', 'visa' ] );
            if ( cards && cards.length > 0 ) {
                this.c2pCards = cards;
                this.currentCardId = cards[ 0 ].srcDigitalCardId;
                const srcCardList = document.querySelector( 'src-card-list' );
                srcCardList.loadCards( cards );
                srcCardList.addEventListener( 'click', ( event ) => {
                    let validIndex = null;
                    event.path.forEach( ( item, index ) => {
                        if ( item.localName == 'src-card' ) {
                            validIndex = index;
                        }
                    } );
                    this.currentCardId = event.path[ validIndex ].getAttribute( 'src-digital-card-id' );
                    this.clientData.card = this.getInformationCardForC2P.panBin;
                    this.onBlur();
                } );
                this.paymentTypeSelected = 'c2p';
                if ( cards.length === 1 ) {
                    this.clientData.card = cards[ 0 ].panBin;
                    this.onBlur();
                }
            }
            
        } catch( err ) {
            // @todo show some error on UI
        }
    },
    methods: {
        async sendInformation() {
            const self = this;
            this.makingApiCall = true;
            await self.makeValidations();
            if( self.$refs.paywithForm.validate() ) {
                const currentRequest = localStorage.getItem( 'requestId' );
                if ( !currentRequest ) {
                    localStorage.setItem( 'requestId', this.orderId );
                } else {
                    return;
                }
                self.letsRedirect();
                
                if ( self.isAmex ){
                    const token = await self.verifyRecaptcha();
                    self.makeAmexPayment( token );
                } else {
                    const token = await self.verifyRecaptcha();
                    const canContinue = await self.validateToken( token, this.userId );
                    if ( canContinue ) {
                        if( self.avoid3DSVerification ) {
                            self.makeAmexPaymentWithout3DS();
                        } else {
                            self.$axios
                                .post( `${ self.serviceApi }/validate/${ self.orderId }`, {
                                    ...self.clientData,
                                    ip: this.ip,
                                } )
                                .then( ( { data } ) => {
                                    if ( data.htmlEntity ) {
                                        this.htmlEntity = data.htmlEntity
                                        setTimeout( () => {
                                            document.frmHtmlCheckout.submit()
                                        }, 500 )
                                    } else {
                                        this.makeAmexPaymentWithout3DS();
                                    }
                                } )
                                .catch( err =>
                                    self.$nuxt.error( {
                                        message: process.env.DEFAULT_ERROR_PAYWITH
                                    } )
                                )
                                .finally( () => {
                                    this.makingApiCall = false;
                                    localStorage.removeItem( 'requestId' );
                                } )
                        }
                    } else {
                        self.cancelRedirect();
                        this.$nuxt.error( {
                            message: this.envs.VUE_BP_RISK_ERROR,
                            errorCode: this.envs.VUE_BP_RISK_CODE ? this.envs.VUE_BP_RISK_CODE : null,
                            callbackUrl: `/pay/${ this.orderId }`,
                            callbackText: 'Regresar a pantalla de pago'
                        } )
                    }
                }
            } else {
                this.makingApiCall = false;
            }
        },
        async makeAmexPayment( token ) {
            const self = this;
            this.$axios
                .post( `${ this.serviceApi }/process/amex/${ this.orderId }`, {
                    ...self.clientData,
                    userId: self.userId,
                    recaptcha: token,
                }, {
                    timeout: 0
                } )
                .then( ( { data } ) => {
                    if ( data.success ) {
                        window.location.href= `/success/${ this.orderId }`;
                    } else {
                        this.cancelRedirect();
                        const statusCode = data.statusCode.toString();
                        if ( data.customPADMessage ) {
                            this.$nuxt.error( {
                                message: data.customPADMessage.message,
                                statusCode: data.customPADMessage.code,
                                errorCode: data.customPADMessage.code,
                                callbackUrl: `/pay/${ this.orderId }`,
                            } )
                        } else {
                            this.$nuxt.error( {
                                message: data.message,
                                statusCode: statusCode,
                                errorCode: statusCode,
                                callbackUrl: `/pay/${ this.orderId }`,
                            } )
                        }
                    }
                } )
                .catch( () => {
                    this.cancelRedirect();
                    this.$nuxt.error( {
                        message: this.envs.VUE_BP_RISK_ERROR,
                        errorCode: this.envs.VUE_BP_RISK_CODE ? this.envs.VUE_BP_RISK_CODE : null,
                        callbackUrl: `/pay/${ this.orderId }`,
                        callbackText: 'Regresar a pantalla de pago'
                    } );
                } )
                .finally( () => {
                    this.makingApiCall = false;
                    localStorage.removeItem( 'requestId' );
                } );
            
        },
        async makeAmexPaymentWithout3DS() {
            this.$axios
                .post( `${ this.serviceApi }/process/without3ds/${ this.orderId }`, this.clientData, {
                    timeout: 0
                } )
                .then( ( { data } ) => {
                    if ( data.success ) {
                        window.location.href= `/success/${ this.orderId }`;
                    } else {
                        this.cancelRedirect();
                        const statusCode = data.statusCode.toString();
                        if ( data.customPADMessage ) {
                            this.$nuxt.error( {
                                message: data.customPADMessage.message,
                                statusCode: data.customPADMessage.code,
                                errorCode: data.customPADMessage.code,
                                callbackUrl: `/pay/${ this.orderId }`,
                            } )
                        } else {
                            this.$nuxt.error( {
                                message: data.message,
                                statusCode: statusCode,
                                errorCode: statusCode,
                                callbackUrl: `/pay/${ this.orderId }`,
                            } )
                        }   
                    }
                } )
                .catch( err =>
                    this.$nuxt.error( {
                        message: process.env.DEFAULT_ERROR_PAYWITH
                    } )
                )
                .finally( () => {
                    this.makingApiCall = false;
                    localStorage.removeItem( 'requestId' );
                } );
        },
        letsRedirect() {
            this.redirectDialog = true
            this.redirectFlag = true
        },
        cancelRedirect() {
            this.redirectFlag = false
            this.redirectDialog = false
        },
        onBlur() {
            const self = this;
            this.atLeastOneBlur = true;
            if ( self.clientData.card === '' ) {
                this.selectedMonth = 1;
                this.canApply = false;
                this.clientData.payment_method = 1;
            } 
            else if( this.paymentTypeSelected === 'c2p' ||
              ( self.clientData.card !== '' && luhn.validate( this.clientData.card ) ) ) {
                self.clientData.payment_method = 1;
                self.showMSI = true;
                self.canApply = false;
                this.currentIssuer = '';
                this.$axios
                    .post( `${ this.serviceApi }/bin/validate`, { card: this.clientData.card } )
                    .then( ( { data } ) => {
                        if ( data.validated ) {
                            this.canApply = true;
                        }
                        self.selectedMonth = {
                            text: `1 pago de ${ this.total }`,
                            month: 1,
                            readonly: false
                        }
                        if ( data.plans && data.plans.length > 0 ) {
                            self.availablePLans = data.plans;
                        }
                        if ( data.canUseDigitalWallet ) {
                            this.showCustomBanner = data.canUseDigitalWallet.canUseDigitalWallet;
                        }
                        if ( this.isAmex ) {
                            this.currentIssuer = 'AMEX';
                        }
                        else if ( data.canUseDigitalWallet &&  data.canUseDigitalWallet.issuer === 'BANCOMER' ) {
                            this.currentIssuer = 'BBVA';
                        }
                        else if ( data.isInternationalCard ) {
                            this.currentIssuer = 'INTERNATIONAL';
                        }
                    } )
                    .catch( () => {  } );
            }
        },
        onChange() {
            this.clientData.payment_method = this.selectedMonth;
            if ( this.selectedMonth !== 1 ) {
                const planWasFound = this.plans.find( item => item.months === this.selectedMonth );
                if ( planWasFound ) {
                    this.clientData.typeMonthlyPayment = planWasFound.type;
                    this.subtotal = planWasFound.realAmount;
                }
            } else {
                this.clientData.typeMonthlyPayment = '';
            }
        },
        getAmountWithCommas( amount ) {
            return this.fixedDigits( amount );
        }, 
        showBanks() {
            this.dialogForBanks = true;
        },
        handlerCloseModal() {
            this.dialogForBanks = false;
            this.showC2PCardList = false;
        },
        makeValidations() {
            this.rules =  {
                required: value => !!value || 'Campo Requerido.',
                strings: value =>
                    /^[a-zA-ZÀ-ú ]+$/.test( value ) || 'Solo se permiten letras y tildes.',
                isValidCard: value =>
                    luhn.validate( value ) || 'Debe introducir una tarjeta valida.',
                isValidExpDate: value => validExpDate( value ),
                emailRules: [
                    v => !!v || 'Correo es requerido.',
                    // eslint-disable-next-line max-len
                    v => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( v ) || 'El correo debe ser válido.'
                ],
                phoneRules: v => !!v || 'El teléfono es requerido',
                isAmex: [
                    v => !!v || 'Campo Requerido.'
                ]
            }
            if ( this.isAmex ) {
                this.rules.isAmex = [
                    v => !!v || 'Campo Requerido.',
                    v => v ?  v.length === 4 || 'El cvv debe ser de 4 dígitos.' : ''
                ]
            }
        },
        verifyRecaptcha() {
            const self = this;
            return new Promise( resolve =>  {
            // eslint-disable-next-line no-undef
                grecaptcha.ready( function() {
                // eslint-disable-next-line no-undef
                    grecaptcha.execute( self.envs.VUE_RECAPTCHA_KEY ,
                        { action: 'ecommerce' } ).then( function( token ) {
                        resolve( token );
                    } );
                } );
            } );
        },
        async validateToken( token, userId ) {
            const { data } = await this.$axios.post( `${ this.serviceApi }/recaptcha/validate`, {
                recaptcha: token,
                userId: userId
            } );
            return data.success;
        },
        async startTransactionWithCard() {
            const popupWindow = window.
                open( '','popUpWindow',
                    // eslint-disable-next-line max-len
                    'height=500,width=500,left=100,top=100,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes' );
            const c2p = await this.initializeClick2Pay( this.envs.SRC_APP_ID,
                this.envs.C2P_ALLOWED_BRANDS || [ 'mastercard', 'visa' ] );
            c2p.checkoutWithCard( {
                srcDigitalCardId: this.currentCardId,
                windowRef: popupWindow,
            } )
                .then( result => {
                    // pending to get a valida response and get token to sen to the backend
                } )
                .catch( err => {
                    // show some error on UI
                } );
          
        }
    }
}
</script>

<style scoped>
.items-container-scroll {
  max-height: 40vh;
  overflow-y: auto;
  border: dashed 0.1em #ced1cf;
  border-radius: 0.3em;
  /* background-color: #F9FCFF; */
}
iframe {
  margin-top: 20px;
  border: 1px solid #666;
}
/* If the screen size is 600px wide or less, set the font-size of <div> to 30px */
@media screen and (max-width: 600px) {
  .price-text {
    font-size: 3rem;
    margin-top: 0 !important;
  }
  .price-sign {
    justify-content: center;
  }
}
.showBanks{
  text-decoration: none;
  cursor: pointer;
}
#c2pCardListDiv{
    max-height: 300px;
    overflow: scroll;
    overflow-x: hidden
}
</style>
