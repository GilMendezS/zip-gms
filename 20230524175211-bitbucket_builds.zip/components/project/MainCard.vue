<template>
  <VFlex mt-4>
    <VLayout
      align-center justify-center
      row fill-height
    >
      <VFlex
        xl10 md11 sm12
      >
        <div v-html="htmlEntity" />
        <VCard>
          <div
            class="pa-2" :style="`background-color: ${color}`"
          />

          <VLayout
            row wrap
            justify-center pa-4 mt-2
          >
            <VFlex
              md4 sm12 px-2
            >
              <p class="title">
                <VIcon :color="color" class="mr-3">
                  shopping_cart
                </VIcon>
                Compra #{{ externalId }}
              </p>

              <VList
                subheader dense class="items-container-scroll py-3"
              >
                <VSubheader>Artículos</VSubheader>

                <VListTile v-for="(item, $index) in items" :key="$index">
                  <VListTileContent>
                    <VListTileTitle> {{ item }}</VListTileTitle>
                  </VListTileContent>
                </VListTile>
              </VList>

              <p class="subheading mb-1 mt-4 grey--text text-xs-center">
                Total
              </p>
              <p class="title text-xs-center">
                {{ total | currency }}
              </p>
            </VFlex>

            <VFlex
              md8 sm12 px-3
            >
              <p class="title text-xs-center text-md-left">
                Método de pago
              </p>
              <VForm
                ref="paywithForm"
                class="my-5"
                @submit.prevent="sendInformation"
              >
                <VLayout
                  row wrap
                  my-3
                >
                  <VFlex px-1>
                    <p class="subheading my-0 font-weight-medium">
                      E-mail
                    </p>
                    <VTextField
                      id="useremail"
                      v-model.trim="clientData.email"
                      name="useremail"
                      autocomplete="email"
                      placeholder="E-mail"
                      prepend-inner-icon="email"
                      :color="color"
                      :rules="rules.cardholderEmail"
                    />
                  </VFlex>

                  <VFlex px-1>
                    <p class="subheading my-0 font-weight-medium">
                      Teléfono
                    </p>
                    <VTextField
                      id="userphone"
                      v-model.trim="clientData.phone"
                      name="userphone"
                      placeholder="Teléfono"
                      prepend-inner-icon="phone"
                      mask="##########"
                      :color="color"
                      :rules="rules.cardholderPhone"
                    />
                  </VFlex>
                </VLayout>
                <VLayout
                  row wrap
                  my-3
                >
                  <VFlex px-1>
                    <p class="subheading my-0 font-weight-medium">
                      Nombre(s)
                    </p>
                    <VTextField
                      id="name"
                      v-model.trim="clientData.name"
                      name="name"
                      autocomplete="cc-name"
                      placeholder="Nombre(s)"
                      prepend-inner-icon="person"
                      :color="color"
                      :rules="[rules.required, rules.strings]"
                    />
                  </VFlex>

                  <VFlex px-1>
                    <p class="subheading my-0 font-weight-medium">
                      Apellidos
                    </p>
                    <VTextField
                      id="lastname"
                      v-model.trim="clientData.lastname"
                      name="lastname"
                      placeholder="Apellidos"
                      prepend-inner-icon="person"
                      :rules="amexRule"
                      :color="color"
                    />
                  </VFlex>
                </VLayout>
                <VLayout
                  row wrap
                  my-3
                >
                  <VFlex px-1>
                    <p class="subheading my-0 font-weight-medium">
                      Número de tarjeta
                    </p>
                    <VTextField
                      id="card"
                      v-model.trim="clientData.card"
                      name="card"
                      autocomplete="cc-number"
                      :placeholder="placeholderCard"
                      prepend-inner-icon="credit_card"
                      :mask="cardDigits"
                      :color="color"
                      :rules="[rules.required, rules.isValidCard]"
                      @blur="onBlur"
                    />
                    <span v-show="internationalCardAmountExceeded" class="red--text">
                      {{ getIssuerAmountExceeded }}
                    </span>
                  </VFlex>
                </VLayout>
                <VLayout
                  row wrap
                  my-3
                >
                  <VFlex px-1>
                    <p class="subheading my-0 font-weight-medium">
                      Vigencia
                    </p>
                    <VTextField
                      id="period"
                      v-model.trim="clientData.period"
                      name="period"
                      autocomplete="cc-exp"
                      placeholder="MM/YY" :color="color"
                      mask="##/##" :rules="[rules.required, rules.isValidExpDate]"
                    />
                  </VFlex>

                  <VFlex px-1>
                    <p class="subheading my-0 font-weight-medium">
                      Código CVV
                    </p>
                    <VTextField
                      id="cvv"
                      v-model.trim="clientData.cvv"
                      type="password"
                      name="cvv"
                      autocomplete="cc-csc"
                      :placeholder="placeholderDigits" :color="color"
                      :mask="cvvDigits" append-outer-icon="help"
                      :rules="[rules.required]"
                      @click:append-outer="cvvMessage = !cvvMessage"
                      @keyup.enter="letsRedirect"
                    />
                  </VFlex>
                </VLayout>
                <div v-if="cvvMessage">
                  <VLayout
                    align-center justify-center row
                    wrap px-3
                  >
                    <VFlex
                      xs12 sm3
                      class="text-xs-center text-sm-left"
                    >
                      <img
                        src="~/assets/credit-cardCVV.svg" alt="credit_card"
                        height="45"
                      >
                    </VFlex>
                    <VFlex sm9 class="text-xs-center text-sm-left">
                      <p class="subheading blue-grey--text">
                        Es el código de 3 o 4 dígitos ubicado al reverso de la tarjeta.
                      </p>
                    </VFlex>
                  </VLayout>
                </div>
                <VLayout
                  row wrap
                  my-3
                >
                  <VFlex>
                    <p class="subheading my-0 font-weight-medium">
                      Planes de pago
                    </p>
                    <p class="grey--text mb-0">
                      Hasta 24 mensualidades
                      <span
                        href="#"
                        class="blue--text showBanks"
                        @click="showBanks"
                      >
                        Ver tarjetas participantes
                      </span>
                    </p>
                    <VSelect
                      id="selectPlans"
                      v-model="selectedMonth"
                      :items="monthsList"
                      :dense="true"
                      item-text="text"
                      item-value="month"
                      item-disabled="readonly"
                      @change="onChange"
                    />
                    <p 
                      v-if="userIsUsingPlan"
                      class="grey--text mt-0"
                    >
                      Monto total a pagar: ${{ fixedSubtotal }}
                    </p>
                  </VFlex>
                </VLayout>
                <div 
                  v-if="isAmex"
                >
                  <p class="help-amex">
                    American Express solicita los siguientes datos para proteger tu compra.
                  </p>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Correo
                      </p>
                      <VTextField
                        id="email"
                        v-model.trim="clientData.email"
                        name="correo"
                        autocomplete="email"
                        :color="color"
                        :rules="rules.emailRules"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Teléfono
                      </p>
                      <VTextField
                        id="phone"
                        v-model.trim="clientData.phone"
                        name="phone"
                        :color="color"
                        mask="##########"
                        :rules="[rules.phoneRules]"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Código Postal
                      </p>
                      <VTextField
                        id="zipcode"
                        v-model.trim="clientData.zipcode"
                        name="zipcode"
                        mask="#####"
                        autocomplete="zipcode"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Colonia
                      </p>
                      <VTextField
                        id="neighborhood"
                        v-model.trim="clientData.neighborhood"
                        name="neighborhood"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Calle
                      </p>
                      <VTextField
                        id="street"
                        v-model.trim="clientData.street"
                        name="street"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Numero Exterior
                      </p>
                      <VTextField
                        id="address_1"
                        v-model.trim="clientData.address_1"
                        name="address_1"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Numero Interior
                      </p>
                      <VTextField
                        id="address_2"
                        v-model.trim="clientData.address_2"
                        name="address_2"
                        :color="color"
                      />
                    </VFlex>
                  </VLayout>
                </div>
                <VBtn
                  type="submit"
                  block color="blue-grey darken-3" class="white--text"
                  :loading="redirectDialog"
                  :disabled="internationalCardAmountExceeded || makingApiCall"
                >
                  Realizar pago
                </VBtn>
              </VForm>
            </VFlex>
          </VLayout>
        </VCard>
      </VFlex>
    </VLayout>
    <VDialog
      v-model="redirectDialog" persistent transition="dialog-transition"
      max-width="400px"
    >
      <VCard>
        <VCardText>
          <VLayout
            align-center justify-center
            column fill-height
          >
            <p class="subheading text-xs-center blue-grey--text darken-2">
              En 5 segundos, será redirigido para validar los datos de su tarjeta.
            </p>
            <VProgressLinear
              :indeterminate="true" :color="color"
              class="my-4"
            />

            <VBtn
              block color="blue-grey darken-3" dark
              outline
              @click.native="cancelRedirect"
            >
              Cancelar
            </VBtn>
          </VLayout>
        </VCardText>
      </VCard>
    </VDialog>
    <!-- modal for banks -->
    <VModalOfBanks :is-open="dialogForBanks" @closeModal="handlerCloseModal" />
  </VFlex>
</template>

<script>
/* eslint-disable complexity */
/* eslint-disable no-useless-escape */
import luhn from 'luhn';
import validExpDate from '@/utils/valid.exp-date';
import cardMixin from '@/mixins/amex.mixin.js';
import amountMixin from '@/mixins/amount.mixin.js';
import ModalOfBanks from '@/components/project/ModalOfBanks.vue';

export default {
    name: 'MainCard',
    components: {
        'VModalOfBanks': ModalOfBanks
    },
    mixins: [ cardMixin, amountMixin ],
    props: {
        color: { type: String, required:true },
        orderId: { type: String, required:true },
        externalId: { type: String, required:true },
        redirectUrl: { type: String, required:true },
        items: { type: Array, required:true },
        total: { type: String, required:true },
        serviceApi: { type: String, required:true },
        excluded: { type: String, required:true },
        plans: { type: Array, default: null },
        disabled3ds: { type: Boolean, default: false },
        disabledSiftForm: { type: Boolean, default: false },
        userId: { type: Number, default: null },
        siftBeaconKey: { type: String, default: '' },
        unlimitedInternationalCards: { type: Boolean, default: false },
        envs: { type: Object, required: true },
        ip: { type: String, required: true },
    }, data(){
        return {
            formPayment: null,
            selectedMonth: 1,
            atLeastOneBlur: false,
            availablePLans: [],
            clientData: {
                name: '',
                lastname: '',
                card: null,
                period: null,
                cvv: null,
                typeMonthlyPayment: '',
                email: '',
                phone: '',
            },
            cvvDigits: '####',
            placeholderDigits: '***',
            cardDigits: '#### - #### - #### - ####',
            placeholderCard: 'xxxx - xxxx - xxxx - xxxx',
            cvvMessage: false,
            redirectDialog: false,
            redirectFlag: false,
            htmlEntity: null,
            dialogForBanks: false,
            currentIssuer:'',
            makingApiCall: false,
            rules: {
                required: value => !!value || 'Campo Requerido.',
                strings: value =>
                    /^[a-zA-ZÀ-ú ]+$/.test( value ) || 'Solo se permiten letras y tildes.',
                isValidCard: value =>
                    luhn.validate( value ) || 'Debe introducir una tarjeta valida.',
                isValidExpDate: value => validExpDate( value ),
                emailRules: [
                    v => !!v || 'E-mail es requerido',
                    // eslint-disable-next-line max-len
                    v => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( v ) || 'El correo debe ser válido.'
                ],
                phoneRules: v => !!v || 'El teléfono es requerido',
                cardholderEmail: [],
                cardholderPhone: [],
                isAmex: v => {
                    return true;
                }
            }
        }
    },
    computed: {
        isAmex() {
            if ( this.clientData.card && luhn.validate( this.clientData.card ) ) {
                if ( this.clientData.card.startsWith( '37' ) || this.clientData.card.startsWith( '34' ) ){
                    return true;
                }
            }
            return false;
        },
        amexRule() {
            const rules = [];
            if( this.isAmex ) {
                const rule = v => !!v || 'Campo Requerido';
                rules.push( rule );
            }
            return rules;
        },
        avoid3DSVerification() {
            if ( this.envs.status3dsForMerchants === 'disabled' ) {
                return true;
            }
            if( this.disabled3ds ) {
                return true;
            }
            try {
                const bines = this.excluded;
                const binesAsArray = bines.split( ',' );
                if( this.clientData.card === null ) {
                    return false;
                }
                const binOfCard = this.clientData.card.substring( 0, 6 );
                if ( binesAsArray.includes( binOfCard ) ) {
                    return true;
                }
                return false;
            } catch( err ) {
                return false;
            }
            
        },
        monthsList() {
            const self = this;
            if ( !self.canApplyPaymentSchemas ) {
                return [
                    {
                        text: `1 pago de $${ this.total }`,
                        month: 1,
                        readonly: true,
                    }
                ];
            }
            if ( !self.atLeastOneBlur ) {
                return [
                    {
                        text: 'Introduce primero tu tarjeta',
                        month: 1,
                        readonly: true,
                    }
                ];
            }
            return self.plans.map( item => {
                const transformedAmount = self.getAmountWithCommas( item.amountPerMonth );
                const data =  {
                    text: `${ item.months  } ${ item.months > 1 ?
                        'pagos mensuales' :
                        'pago ' } de $${ transformedAmount }`,
                    month: item.months,
                  
                };
                if ( self.availablePLans.includes( item.months ) ) {
                    data.readonly = !self.canApply;
                } else {
                    data.readonly = true;
                    if ( item.months !== 1 ) {
                        data.text += ' (No disponible para tu tarjeta, consulta tarjetas participantes)';
                    }
                    
                }
                if ( item.months === 1 ) {
                    data.readonly = false;
                }
                return data;
            } );
        },
        canApplyPaymentSchemas() {
            const FloatTotal = parseFloat( this.total );
            const minimumAmount = 300.0;
            return FloatTotal >= minimumAmount;
        },
        userIsUsingPlan() {
            return this.selectedMonth > 1;
        },
        fixedSubtotal() {
            return this.fixedDigits( this.subtotal );
        },
        getMessageForInternationalCards() {
            const messageToShow = this.envs.LIMIT_MESSAGE;
            return 'Tarjetas emitidas fuera de México '
              + messageToShow.replace( '{amount}', this.envs.LIMIT_FOR_INTERNATIONAL_CARDS  );
        },
        getIssuerAmountExceeded() {
            if ( this.currentIssuer === 'INTERNATIONAL' ) {
                return this.getMessageForInternationalCards;
            }
            return '';
        },
        floatAmount() {
            return parseFloat( this.total );
        },
        internationalCardAmountExceeded() {
            if ( this.currentIssuer === 'INTERNATIONAL' && this.unlimitedInternationalCards ) {
                return false;
            }
            return this.currentIssuer === 'INTERNATIONAL' && this.floatAmount > this.envs.LIMIT_FOR_INTERNATIONAL_CARDS;
        },
    },
    watch: {
        clientData: {
            deep: true,
            handler: function () {
                if ( this.clientData.card
                  && ( this.clientData.card.startsWith( '37' ) || this.clientData.card.startsWith( '34' ) ) ){
                    this.cardDigits = '#### - ###### - #####';
                    this.placeholderDigits = '****';
                } else {
                    this.cardDigits = '#### - #### - #### - ####';
                    this.placeholderDigits = '***';
                }
            },
        }
    },
    beforeMount() {
        if ( !this.disabledSiftForm ) {
            this.rules.cardholderEmail = [
                v => !!v || 'E-mail es requerido',
                // eslint-disable-next-line max-len
                v => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( v ) || 'El correo debe ser válido.'
            ];
            this.rules.cardholderPhone = [
                v => !!v || 'El teléfono es requerido',
            ]
        }
    },
    mounted() {
        const _user_id = this.userId.toString();
        const _sift = window._sift = window._sift || [];
        _sift.push( [ '_setAccount', this.siftBeaconKey ] );
        _sift.push( [ '_setUserId', _user_id ] );
        _sift.push( [ '_trackPageview' ] );

        ( function() {
            function ls() {
                const e = document.createElement( 'script' );
                e.src = 'https://cdn.sift.com/s.js';
                document.body.appendChild( e );
            }
            if ( window.attachEvent ) {
                window.attachEvent( 'onload', ls );
            } else {
                window.addEventListener( 'load', ls, false );
            }
        } )();
        const recaptchaScript = document.createElement( 'script' );
        recaptchaScript.async = true;
        recaptchaScript.defer = true;
        recaptchaScript.setAttribute( 'src', `https://www.google.com/recaptcha/api.js?render=${ this.envs.VUE_RECAPTCHA_KEY }` );
        document.head.appendChild( recaptchaScript );
    },
    methods:{
        async sendInformation(){
            this.makingApiCall = true;
            await this.verifyChanges();
            
            const validForm = this.$refs.paywithForm.validate();
            if( validForm ){
                this.letsRedirect();
                if ( this.isAmex ){
                    this.makeAmexPayment();
                } 
                else if( this.avoid3DSVerification ) {
                    this.makeAmexPaymentWithout3DS();
                } else {
                    this.$axios
                        .post( `${ this.serviceApi }/validate/${ this.orderId }`, this.clientData )
                        .then( ( { data } ) => {
                            if ( data.htmlEntity ) {
                                this.htmlEntity = data.htmlEntity
                                setTimeout( () => {
                                    document.frmHtmlCheckout.submit()
                                }, 500 )
                            } else {
                                this.makeAmexPaymentWithout3DS();
                            }
                            
                        } )
                        .catch( err =>
                            this.$nuxt.error( {
                                message: process.env.DEFAULT_ERROR_PAYWITH
                            } )
                        )
                        .finally( () => {
                            this.makingApiCall = false;
                        } )
                }
                
            } else {
                this.makingApiCall = false;
            }
            
        },
        async makeAmexPayment() {
            const self = this;
            const token = await self.verifyRecaptcha();
            this.$axios
                .post( `${ this.serviceApi }/process/amex/${ this.orderId }`, {
                    ...self.clientData,
                    ip: this.ip,
                    recaptcha: token,
                }, {
                    timeout: 0
                } )
                .then( ( { data } ) => {
                    if ( data.success ) {
                        window.location.href= `/success/${ this.orderId }`;
                    } else {
                        this.cancelRedirect();
                        const statusCode = data.statusCode.toString();
                        
                        this.$nuxt.error( {
                            message: data.message,
                            statusCode: statusCode,
                            errorCode: statusCode,
                            callbackUrl: `/checkout/${ this.orderId }`,
                        } )
                    }
                } )
                .catch( err =>
                    this.$nuxt.error( {
                        message: 'Ha surgido un error, por favor vuelve a intentarlo.',
                        statusCode: 500,
                        errorCode: 500,
                        callbackUrl: `/checkout/${ this.orderId }`,
                    } )
                )
                .finally( () => {
                    this.makingApiCall = false;
                } );
            
        },
        async makeAmexPaymentWithout3DS() {
            const self = this;
            this.$axios
                .post( `${ this.serviceApi }/process/without3ds/${ this.orderId }`, {
                    ...self.clientData,
                    ip: this.ip,
                }, {
                    timeout: 0
                } )
                .then( ( { data } ) => {
                    if ( data.success ) {
                        window.location.href= `/success/${ this.orderId }`;
                    } else {
                        this.cancelRedirect();
                        const statusCode = data.statusCode.toString();
                        this.$nuxt.error( {
                            message: data.message,
                            statusCode: statusCode,
                            errorCode: statusCode,
                            callbackUrl: `/checkout/${ this.orderId }`,
                        } )
                    }
                } )
                .catch( err =>
                    this.$nuxt.error( {
                        message: 'Ha surgido un error, por favor vuelve a intentarlo.',
                        statusCode: 500,
                        errorCode: 500,
                        callbackUrl: `/checkout/${ this.orderId }`,
                    } )
                )
                .finally( () => {
                    this.makingApiCall = false;
                } );
            
        },
        letsRedirect(){
            this.redirectDialog = true;
            this.redirectFlag = true;
        },
        cancelRedirect(){
            this.redirectFlag = false;
            this.redirectDialog = false;
        },
        verifyChanges() {
            const name = document.querySelector( '#name' ).value;
            const card = document.querySelector( '#card' ).value;
            const period = document.querySelector( '#period' ).value;
            const cvv = document.querySelector( '#cvv' ).value;

            if( this.clientData.name === '' && name !== '' ){
                this.clientData.name = name;
            }
            if( this.clientData.card === null && card !== '' ){
                this.clientData.card = card;
            }
            if( this.clientData.period === null && period !== '' ){
                this.clientData.period = period;
            }
            if( this.clientData.cvv === null && cvv !== '' ){
                this.clientData.cvv = cvv;
            }
            const userEmail = document.querySelector( '#useremail' ).value;
            const userPhone = document.querySelector( '#userphone' ).value;
            if( this.clientData.email === '' && userEmail !== '' ){
                this.clientData.email = userEmail;
            }
            if( this.clientData.phone === '' && userPhone !== '' ){
                this.clientData.phone = userPhone;
            }
            
        },
        showBanks() {
            this.dialogForBanks = true;
        },
        handlerCloseModal() {
            this.dialogForBanks = false;
        },
        onChange() {
            this.clientData.payment_method = this.selectedMonth;
            if ( this.selectedMonth !== 1 ) {
                const planWasFound = this.plans.find( item => item.months === this.selectedMonth );
                if ( planWasFound ) {
                    this.clientData.typeMonthlyPayment = planWasFound.type;
                    this.subtotal = planWasFound.realAmount;
                }
            } else {
                this.clientData.typeMonthlyPayment = '';
            }
        },
        onBlur() {
            const self = this;
            this.atLeastOneBlur = true;
            if ( self.clientData.card === '' ) {
                this.selectedMonth = 1;
                this.canApply = false;
                this.clientData.payment_method = 1;
            } 
            else if( self.clientData.card !== ''
            && self.canApplyPaymentSchemas && luhn.validate( this.clientData.card ) ) {
                self.clientData.payment_method = 1;
                self.showMSI = true;
                self.canApply = false;
                this.currentIssuer = '';
                this.$axios
                    .post( `${ this.serviceApi }/bin/validate`, { card: this.clientData.card } )
                    .then( ( { data } ) => {
                        if ( data.validated ) {
                            this.canApply = true;
                        }
                        self.selectedMonth = {
                            text: `1 pago de ${ this.total }`,
                            month: 1,
                            readonly: false
                        }
                        if ( data.plans && data.plans.length > 0 ) {
                            self.availablePLans = data.plans;
                        }
                        if ( data.isInternationalCard ) {
                            this.currentIssuer = 'INTERNATIONAL';
                        }
                    } )
                    .catch( () => {  } );
            }
        },
        getAmountWithCommas( amount ) {
            return this.fixedDigits( amount );
        },
        verifyRecaptcha() {
            const self = this;
            return new Promise( resolve =>  {
            // eslint-disable-next-line no-undef
                grecaptcha.ready( function() {
                // eslint-disable-next-line no-undef
                    grecaptcha.execute( self.envs.VUE_RECAPTCHA_KEY ,
                        { action: 'ecommerce' } ).then( function( token ) {
                        resolve( token );
                    } );
                } );
            } );
        },
        
    },
}
</script>

<style scoped>
.items-container-scroll{
    max-height: 40vh;
    overflow-y: auto;
    border: dashed 0.1em #CED1CF;
    border-radius: 0.3em;
    /* background-color: #F9FCFF; */
}
iframe {
    margin-top: 20px;
    border: 1px solid #666;
  }
</style>
