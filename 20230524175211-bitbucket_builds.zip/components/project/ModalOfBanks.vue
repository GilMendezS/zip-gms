<template>
  <VDialog
    v-model="isOpen"
    :persistent="persistent"
    max-width="600px"
  >
    <VCard class="pl-3">
      <VCardTitle>
        <h1 class="modalTitle">
          Tarjetas de crédito participantes
        </h1>
        <VSpacer />
        <VIcon
          class="text-right" @click="sendEvent"
        >
          close
        </VIcon>
      </VCardTitle>
      <VCardText>
        <VLayout class="">
          <VFlex mt-2>
            <h2 class="subtitleModal pl-2">
              3, 6, 9, 12, 18 y 24 pagos mensuales
            </h2>
          </VFlex>
        </VLayout>
        <VLayout class="">
          <VFlex mt-2>
            <img
              src="~/assets/bancos/01-bbva.png" alt="BBVA"
              height="55"
            >
          </VFlex>
          <VFlex mt-2>
            <img
              src="~/assets/bancos/02-amex.png" alt="AMEX"
              height="55"
            >
          </VFlex>

          <VFlex mt-2>
            <img
              src="~/assets/bancos/03-citibanamex.png" alt="BANAMEX"
              height="55"
            >
          </VFlex>
        </VLayout>
        <VLayout class="">
          <VFlex mt-2>
            <h2 class="subtitleModal pl-2">
              3, 6, 9, 12 y 18 pagos mensuales
            </h2>
          </VFlex>
        </VLayout>
        <VLayout>
          <VFlex>
            <img
              src="~/assets/bancos/04-hsbc.png" alt="HSBC"
              height="55"
            >
          </VFlex>
          <VFlex>
            <img
              src="~/assets/bancos/05-santander.png" alt="SANTANDER"
              height="55"
            >
          </VFlex>

          <VFlex>
            <img
              src="~/assets/bancos/06-banregio.png" alt="BANREGIO"
              height="40"
            >
          </VFlex>
          <VFlex>
            <img
              src="~/assets/bancos/07-scotiabank.png" alt="SCOTIABANK"
              height="55"
            >
          </VFlex>
        </VLayout>
        <VLayout
          row
          fill-height
          class=""
        >
          <VFlex>
            <img
              src="~/assets/bancos/08-banorte.png" alt="BANORTE"
              height="55"
            >
          </VFlex>
          <VFlex>
            <img
              src="~/assets/bancos/09-afirme.png" alt="AFIRME"
              height="55"
            >
          </VFlex>

          <VFlex>
            <img
              src="~/assets/bancos/10-bancofamsa.png" alt="BANCO FAMSA"
              height="55"
            >
          </VFlex>
          <VFlex>
            <img
              src="~/assets/bancos/11-banbajio.png" alt="BANBAJIO"
              height="55"
            >
          </VFlex>
        </VLayout>
        <VLayout
          row
          fill-height
          class=""
        >
          <VFlex>
            <img
              src="~/assets/bancos/12-inbursa.png" alt="INBURSA"
              height="55"
            >
          </VFlex>
          <VFlex>
            <img
              src="~/assets/bancos/13-invex.png" alt="INVEX"
              height="55"
            >
          </VFlex>

          <VFlex>
            <img
              src="~/assets/bancos/14-liverpool.png" alt="LIVERPOOL"
              height="55"
            >
          </VFlex>
          <VFlex>
            <img
              src="~/assets/bancos/15-ixe.png" alt="IXE"
              height="55"
            >
          </VFlex>
        </VLayout>
        <VLayout
          row
          fill-height
          class=""
        >
          <VFlex>
            <img
              src="~/assets/bancos/16-mifel.png" alt="MIFEL"
              height="55"
            >
          </VFlex>
          <VFlex>
            <img
              src="~/assets/bancos/17-banjercito.png" alt="BANJERCITO"
              height="55"
            >
          </VFlex>

          <VFlex>
            <img
              src="~/assets/bancos/18-konfio.png" alt="KONFIO"
              height="55"
            >
          </VFlex>
          <VFlex>
            <img
              src="~/assets/bancos/19-falabella.png" alt="FALABELLA"
              height="55"
            >
          </VFlex>
        </VLayout>
        <p class="grey--text">
          El monto mínimo para pagos mensuales es de $300
        </p>
      </VCardText>
    </VCard>
  </VDialog>
</template>
<script>
export default {
    props: {
        isOpen: { type: Boolean }
    },
    data: () => ( {
        persistent: true,
    } ),
    methods: {
        sendEvent() {
            this.$emit( 'closeModal' );
        },
    }
}
</script>
<style scoped>
    /* If the screen size is 600px wide or less, set the font-size of <div> to 30px */
@media screen and (max-width: 600px) {
  img {
      height: 30px;
  }
  .modalTitle {
    font-size: 1em;
  }
  .subtitleModal {
    font-size: 0.8em;
  }
}
</style>