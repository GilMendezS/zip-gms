<template>
  <VFlex mt-4>
    <VLayout
      align-center justify-center
      row fill-height
    >
      <VFlex
        xl10 md11 sm12
      >
        <div v-html="htmlEntity" />
        <VCard>
          <div
            class="pa-2" :style="`background-color: ${color}`"
          />

          <VLayout
            row wrap
            justify-center pa-4 mt-2
          >
            <VFlex
              md4 sm12 px-2
            >
              <CheckoutDetails
                :color="user.colorEntity || 'blue'"
                :checkout="checkout"
              />
            </VFlex>
            <VFlex>
              <VLayout>
                <VFlex
                  md8 sm12 px-3
                >
                  <p class="title text-xs-center text-md-left">
                    Método de pago
                  </p>
                </VFlex>
              </VLayout>
              <VLayout
                row wrap
                ml-2
              >
                <VFlex>
                  <VTabs
                    v-model="active"
                    color="white"
                    :slider-color="tabSliderColor"
                    :height="setTabHeight"
                    @change="onChangePaymentOption"
                  >
                    <VLayout
                      row
                      wrap
                      :style="extraSmallWindow"
                    >
                      <VFlex
                        md4 sm4 xs7
                        :fill-height="!smallWindow()"
                      >
                        <VTab
                          ripple
                          active-class="blue-grey lighten-4"
                        >
                          <p class="text-xs-center ma-0 pa-1">
                            Tarjeta de débito o crédito
                          </p>
                        </VTab>
                      </VFlex>
                      <VFlex
                        md5 sm5 xs7
                        :d-flex="smallWindow()"
                      >
                        <VTab
                          v-if="showC2PUI"
                          active-class="blue-grey lighten-4"
                          ripple
                        >
                          <ClickToPayBrands
                            v-if="showC2PUI"
                            :brands="brands"
                          />
                        </VTab>
                      </VFlex>
                    </VLayout>
                  </VTabs>
                </VFlex>
              </VLayout>
              <VDivider class="mt-3 mb-0" />
              <VLayout
                v-if="showC2PUI"
                v-show="paymentTypeSelected==='c2p'" row
                wrap
              >
                <VFlex v-if="showC2PUI" px-1>
                  <no-ssr>
                    <div v-if="showC2PUI" class="mt-2">
                      <h3>Click to Pay</h3>
                      <p>
                        <span class="grey--text">
                          Pago en línea más rápido y seguro
                        </span>
                        <a
                          href="#"
                          @click="onShowC2PInformation"
                        >
                          Conocer más
                        </a>
                      </p>
                      <src-card-list
                        v-if="showC2PUI"
                        v-show="c2pCards.length > 0 && !addingNewCardForC2P"
                        id="srcCardList"
                        class="card-box" locale="es_MX"
                        :card-brands="c2pBrands"
                        display-preferred-card="true"
                        display-cancel-option="false" display-add-card="true"
                        display-sign-out="true"
                        card-selection-type="radioButton" src-digital-card-id="" display-header="false"
                      />
                    </div>
                  </no-ssr>
                  <div v-if="showC2PUI && c2pCards.length > 0 && !addingNewCardForC2P">
                    <p class="subheading my-0 font-weight-medium">
                      Código CVV
                    </p>
                    <VForm
                      ref="cvvC2pForm"
                    >
                      <VTextField
                        id="cvvc2p"
                        v-model.trim="cvvC2p"
                        type="password"
                        name="cvvc2p"
                        autocomplete="cc-csc"
                        :placeholder="placeholderDigits" :color="color"
                        :mask="cvvDigits" append-outer-icon="help"
                        :rules="rules.isAmex"
                        @click:append-outer="cvvMessage = !cvvMessage"
                      />
                    </VForm>
                  </div>
                  <div v-if="addingNewCardForC2P">
                    <VForm
                      ref="clickToPayForm"
                    >
                      <VLayout
                        row wrap
                        my-3
                      >
                        <VFlex px-1>
                          <p class="subheading my-0 font-weight-medium">
                            Número de tarjeta
                          </p>
                          <VTextField
                            id="cardc2p"
                            v-model.trim="newCardForC2p.card"
                            name="cardc2p"
                            autocomplete="cc-number"
                            :placeholder="placeholderCard"
                            prepend-inner-icon="credit_card"
                            :mask="cardDigits"
                            :color="color"
                            :rules="[rules.required, rules.isValidCard]"
                          />
                          <span v-show="amexAmountExceeded || internationalCardAmountExceeded" class="red--text">
                            {{ getIssuerAmountExceeded }}
                          </span>
                          <VAlert
                            :value="showCustomBanner"
                            color="blue"
                            icon="info"
                            outline
                          >
                            Garantiza mayor aprobación y seguridad pagando con tu Tarjeta Digital de la App BBVA.
                          </VAlert>
                        </VFlex>
                      </VLayout>
                      <VLayout
                        row wrap
                        my-3
                      >
                        <VFlex px-1>
                          <p class="subheading my-0 font-weight-medium">
                            Vigencia
                          </p>
                          <VTextField
                            id="periodc2p"
                            v-model.trim="newCardForC2p.period"
                            name="periodc2p"
                            autocomplete="cc-exp"
                            placeholder="MM/YY" :color="color"
                            mask="##/##" :rules="[rules.required, rules.isValidExpDate]"
                          />
                        </VFlex>

                        <VFlex px-1>
                          <p class="subheading my-0 font-weight-medium">
                            Código CVV
                          </p>
                          <VTextField
                            id="cvvc2p"
                            v-model.trim="newCardForC2p.cvv"
                            type="password"
                            name="cvvc2p"
                            autocomplete="cc-csc"
                            :placeholder="placeholderDigits" :color="color"
                            :mask="cvvDigits" append-outer-icon="help"
                            :rules="rules.isAmex"
                            @click:append-outer="cvvMessage = !cvvMessage"
                          />
                        </VFlex>
                      </VLayout>
                      <VLayout
                        row wrap
                        my-3
                      >
                        <VFlex px-1>
                          <a @click="addingNewCardForC2P = false">Volver a listado de mis tarjetas.</a>
                        </VFlex>
                      </VLayout>
                    </VForm>
                  </div>
                </VFlex>
              </VLayout>
              <VForm
                ref="paywithForm"
                class=""
                @submit.prevent="sendInformation"
              >
                <div v-show="showPaymentForm">
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        E-mail
                      </p>
                      <VTextField
                        id="useremail"
                        v-model.trim="clientData.email"
                        name="useremail"
                        autocomplete="email"
                        placeholder="E-mail"
                        prepend-inner-icon="email"
                        :color="color"
                        :rules="rules.cardholderEmail"
                        @blur="onBlurForEmail"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Teléfono
                      </p>
                      <VTextField
                        id="userphone"
                        v-model.trim="clientData.phone"
                        name="userphone"
                        placeholder="Teléfono"
                        prepend-inner-icon="phone"
                        mask="##########"
                        :color="color"
                        :rules="rules.cardholderPhone"
                        @blur="onBlurForPhone"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Nombre(s)
                      </p>
                      <VTextField
                        id="name"
                        v-model.trim="clientData.name"
                        name="name"
                        autocomplete="cc-name"
                        placeholder="Nombre(s)"
                        prepend-inner-icon="person"
                        :color="color"
                        :rules="[rules.required, rules.strings]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Apellidos
                      </p>
                      <VTextField
                        id="lastname"
                        v-model.trim="clientData.lastname"
                        name="lastname"
                        placeholder="Apellidos"
                        prepend-inner-icon="person"
                        :rules="rules.lastname"
                        :color="color"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Número de tarjeta
                      </p>
                      <VTextField
                        id="card"
                        v-model.trim="clientData.card"
                        name="card"
                        autocomplete="cc-number"
                        :placeholder="placeholderCard"
                        prepend-inner-icon="credit_card"
                        :mask="cardDigits"
                        :color="color"
                        :rules="[rules.required, rules.isValidCard]"
                        @blur="onBlurWithBinOfCard()"
                      />
                      <span v-show="amexAmountExceeded || internationalCardAmountExceeded" class="red--text">
                        {{ getIssuerAmountExceeded }}
                      </span>
                      <VAlert
                        :value="showCustomBanner"
                        color="blue"
                        icon="info"
                        outline
                      >
                        Garantiza mayor aprobación y seguridad pagando con tu Tarjeta Digital de la App BBVA.
                      </VAlert>
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Vigencia
                      </p>
                      <VTextField
                        id="period"
                        v-model.trim="clientData.period"
                        name="period"
                        autocomplete="cc-exp"
                        placeholder="MM/YY" :color="color"
                        mask="##/##" :rules="[rules.required, rules.isValidExpDate]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Código CVV
                      </p>
                      <VTextField
                        id="cvv"
                        v-model.trim="clientData.cvv"
                        type="password"
                        name="cvv"
                        autocomplete="cc-csc"
                        :placeholder="placeholderDigits" :color="color"
                        :mask="cvvDigits" append-outer-icon="help"
                        :rules="rules.isAmex"
                        @click:append-outer="cvvMessage = !cvvMessage"
                        @keyup.enter="letsRedirect"
                      />
                    </VFlex>
                  </VLayout>
                </div>
                <div v-if="cvvMessage">
                  <VLayout
                    align-center justify-center row
                    wrap px-3
                  >
                    <VFlex
                      xs12 sm3
                      class="text-xs-center text-sm-left"
                    >
                      <img
                        src="~/assets/credit-cardCVV.svg" alt="credit_card"
                        height="45"
                      >
                    </VFlex>
                    <VFlex sm9 class="text-xs-center text-sm-left">
                      <p class="subheading blue-grey--text">
                        Es el código de 3 o 4 dígitos ubicado al reverso de la tarjeta.
                      </p>
                    </VFlex>
                  </VLayout>
                </div>
                <VLayout
                  v-if="showCheckboxToCreateAccount && showC2PUI && !isAmex && !currentCardIsVisa"
                  v-show="paymentTypeSelected !== 'c2p'"
                  row wrap
                  my-3
                >
                  <VFlex>
                    <input
                      id="checkedc2p" v-model="createC2pAccount"
                      type="checkbox"
                      name="checkedc2p"
                    >
                    <img
                      src="@/assets/clicktopay.svg"
                      alt="clicktopay"
                      class="ml-1 c2p-img-create-account"
                    >
                    Crear cuenta en Click to Pay <a
                      id="btnInfoC2p"
                      href="#btnInfoC2p"
                      @click="onShowC2PInformation"
                    >Conocer más</a><br>
                    <p v-if="existsValidCard">
                      Al continuar, {{ getCurrentMerchant }} compartirá tus datos de tarjeta y correo electrónico con
                      {{ getCurrentCardBrand }} para registrarte
                      de manera segura en Click to Pay para pagos más rápidos.
                    </p>
                  </VFlex>
                </VLayout>
                <VLayout
                  row wrap
                  my-3
                >
                  <VFlex>
                    <p class="subheading my-0 font-weight-medium">
                      Planes de pago
                    </p>
                    <p class="grey--text mb-0">
                      {{ descMensualidades }}
                      <span
                        href="#"
                        class="blue--text showBanks"
                        @click="showBanks"
                      >
                        Ver tarjetas participantes
                      </span>
                    </p>
                    <VSelect
                      id="selectPlans"
                      v-model="selectedMonth"
                      :items="monthsList"
                      :dense="true"
                      item-text="text"
                      item-value="month"
                      item-disabled="readonly"
                      @change="onChange"
                    />
                    <p
                      v-if="userIsUsingPlan"
                      class="grey--text mt-0"
                    >
                      Monto total a pagar: ${{ fixedSubtotal }}
                    </p>
                  </VFlex>
                </VLayout>
                <div
                  v-if="isAmex"
                >
                  <p class="help-amex">
                    American Express solicita los siguientes datos para proteger tu compra.
                  </p>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Correo
                      </p>
                      <VTextField
                        id="email"
                        v-model.trim="clientData.email"
                        name="correo"
                        autocomplete="email"
                        :color="color"
                        :rules="rules.cardholderEmail"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Teléfono
                      </p>
                      <VTextField
                        id="phone"
                        v-model.trim="clientData.phone"
                        name="phone"
                        :color="color"
                        mask="##########"
                        :rules="[rules.phoneRules]"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Código Postal
                      </p>
                      <VTextField
                        id="zipcode"
                        v-model.trim="clientData.zipcode"
                        name="zipcode"
                        mask="#####"
                        autocomplete="zipcode"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Colonia
                      </p>
                      <VTextField
                        id="neighborhood"
                        v-model.trim="clientData.neighborhood"
                        name="neighborhood"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>
                  </VLayout>
                  <VLayout
                    row wrap
                    my-3
                  >
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Calle
                      </p>
                      <VTextField
                        id="street"
                        v-model.trim="clientData.street"
                        name="street"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>

                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Numero Exterior
                      </p>
                      <VTextField
                        id="address_1"
                        v-model.trim="clientData.address_1"
                        name="address_1"
                        :color="color"
                        :rules="[rules.required]"
                      />
                    </VFlex>
                    <VFlex px-1>
                      <p class="subheading my-0 font-weight-medium">
                        Numero Interior
                      </p>
                      <VTextField
                        id="address_2"
                        v-model.trim="clientData.address_2"
                        name="address_2"
                        :color="color"
                      />
                    </VFlex>
                  </VLayout>
                </div>
                <p v-show="click2PayError" class="red--text">
                  {{ click2PayError }}
                </p>
                <VBtn
                  id="btnSubmit"
                  type="submit"
                  block color="blue-grey darken-3"
                  class="white--text"
                  :loading="redirectDialog"
                  :disabled="amexAmountExceeded || internationalCardAmountExceeded || makingApiCall"
                >
                  Realizar pago
                </VBtn>
              </VForm>
            </VFlex>
          </VLayout>
        </VCard>
      </VFlex>
    </VLayout>
    <VDialog
      v-model="redirectDialog" persistent transition="dialog-transition"
      max-width="400px"
    >
      <VCard>
        <VCardText>
          <VLayout
            align-center justify-center
            column fill-height
          >
            <p class="subheading text-xs-center blue-grey--text darken-2">
              En 5 segundos, será redirigido para validar los datos de su tarjeta.
            </p>
            <VProgressLinear
              :indeterminate="true" :color="color"
              class="my-4"
            />
          </VLayout>
        </VCardText>
      </VCard>
    </VDialog>
    <div v-show="showConfirmation">
      <div id="c2p-bg" class="payment-window-bg" />
      <div id="divToInsertIframe" class="payment-window payment-active" />
    </div>
    <!-- modal for banks -->
    <VModalOfBanks :is-open="dialogForBanks" @closeModal="handlerCloseModal" />
    <!--modal for OTP c2p-->
    <VClickToPayOTP
      v-if="showOtpValidation"
      :is-open="showOtpValidation" :otp-conf="otpConf"
      :brands="c2pBrandsForOTP"
      @closeModal="handlerCloseModal"
      @onRetriesExceeded="handlerRetriesExceeded"
      @changeOtp="changeOtp"
      @otpValue="handlerOptValue"
    />
    <ClickToPayInformation
      :is-open="showDialogClickToPayInformation"
      :brands="c2pBrandsAsArray"
      @closeModal="handlerCloseModal"
    />
    <Loading :is-loading="isLoading" />
  </VFlex>
</template>

<script>
/* eslint-disable complexity */
/* eslint-disable no-useless-escape */
import luhn from 'luhn';
import validExpDate from '@/utils/valid.exp-date';
import cardMixin from '@/mixins/amex.mixin.js';
import amountMixin from '@/mixins/amount.mixin.js';
import ModalOfBanks from '@/components/project/ModalOfBanks.vue';
import CheckoutDetails from '@/components/project/CheckoutDetails.vue';
import ClickToPayOTP from '@/components/project/ClickToPayOTP.vue';
import Loading from '@/components/shared/Loading.vue';
import ClickToPayBrands from '@/components/project/ClickToPayBrands.vue';
import click2Pay from '@/mixins/click2pay.mixin.js';
import ClickToPayBP from '@/utils/click2pay';
import ClickToPayInformation from '@/components/project/ClickToPayInformation.vue';

export default {
    name: 'MainCard',
    components: {
        'VModalOfBanks': ModalOfBanks,
        CheckoutDetails,
        'VClickToPayOTP': ClickToPayOTP,
        Loading,
        ClickToPayBrands,
        ClickToPayInformation
    },
    mixins: [ cardMixin, amountMixin, click2Pay ],
    props: {
        orderId: { type: String, required:true },
        serviceApi: { type: String, required: true },
        excluded: { type: String, required: true },
        envs: { type: Object, required: true },
        checkout: { type: Object, required: true },
        user: { type: Object, required: true },
        plans: { type: Array, default: null },
        permissions: { type: Object, required: true },
    },
    data(){
        return {
            subtotal: '',
            formPayment: null,
            selectedMonth: 1,
            atLeastOneBlur: false,
            availablePLans: [],
            canApply: false,
            clientData: {
                name: '',
                lastname: '',
                card: null,
                period: null,
                cvv: null,
                payment_method: 1,
                typeMonthlyPayment: '',
                email: '',
                phone: '',
            },
            newCardForC2p: {
                card: '',
                period: '',
                cvv: '',
            },
            cvvDigits: '####',
            placeholderDigits: '***',
            cardDigits: '#### - #### - #### - ####',
            placeholderCard: 'xxxx - xxxx - xxxx - xxxx',
            cvvMessage: false,
            showMSI: false,
            redirectDialog: false,
            redirectFlag: false,
            htmlEntity: null,
            dialogForBanks: false,
            currentIssuer:'',
            showCustomBanner: false,
            makingApiCall: false,
            rules: {
                required: true,
                strings: true,
                isValidCard: true,
                isValidExpDate: true,
                emailRules: true,
                phoneRules: true,
                cardholderEmail: [],
                cardholderPhone: [],
                isAmex: [],
                lastname:[],
                amexRule: true,
            },
            showPaymentForm: true,
            paymentTypeSelected: 'default',
            c2pCards: [],
            currentCardId: null,
            showOtpValidation: false,
            otpConf: null,
            isLoading: false,
            brands: [ 'mastercard' ],
            showConfirmation: false,
            c2pInstance: null,
            showCheckboxToCreateAccount: true,
            c2pUserSigned: false,
            createC2pAccount: false,
            cvvC2p: '',
            masterCardCheckout: {
            },
            click2PayError: '',
            requiredCode: true,
            c2pInstanceError: null,
            addingNewCardForC2P: false,
            plans2: [],
            active: null,
            showDialogClickToPayInformation: false,
            tabSliderColor: '',
            setTabHeight: '',
            extraSmallWindow: '',
        }
    },
    computed: {
        isAmex() {
            if ( this.clientData.card && luhn.validate( this.clientData.card ) ) {
                if ( this.clientData.card.startsWith( '37' ) || this.clientData.card.startsWith( '34' ) ){
                    return true;
                }
            }
            return false;
        },
        showAmexForm() {
            return this.clientData.card && this.isAmex && luhn.validate( this.clientData.card );
        },
        fixedValue () {
            return this.fixedDigits( this.total );
        },
        avoid3DSVerification() {
            if ( !this.isPAD && this.envs.status3dsForMerchants === 'disabled' ) {
                return true;
            }
            if( !this.isPAD && this.user.disabled3ds ) {
                return true;
            }
            if ( this.isPAD && this.envs.status3dsPAD === 'disabled' ) {
                return true;
            }
            try {
                const bines = this.excluded;
                const binesAsArray = bines.split( ',' );
                if( this.clientData.card === null ) {
                    return false;
                }
                const binOfCard = this.clientData.card.substring( 0, 6 );
                if ( binesAsArray.includes( binOfCard ) ) {
                    return true;
                }
                return false;
            } catch( err ) {
                return false;
            }

        },
        monthsList() {
            const self = this;
            if ( !self.canApplyPaymentSchemas || !self.canApply ) {
                return [
                    {
                        text: `1 pago de $${ this.checkout.total }`,
                        month: 1,
                        readonly: !self.canApplyPaymentSchemas,
                    }
                ];
            }
            if ( !self.atLeastOneBlur ) {
                return [
                    {
                        text: 'Introduce primero tu tarjeta',
                        month: 1,
                        readonly: true,
                    }
                ];
            }
            return self.plans2.map( item => {
                const transformedAmount = self.getAmountWithCommas( item.amountPerMonth );
                const data =  {
                    text: `${ item.months  } ${ item.months > 1 ?
                        'pagos mensuales' :
                        'pago ' } de $${ transformedAmount }`,
                    month: item.months,

                };
                if ( self.availablePLans.includes( item.months ) ) {
                    data.readonly = !self.canApply;
                } else {
                    data.readonly = true;
                    if ( item.months !== 1 ) {
                        data.text += ' (No disponible para tu tarjeta, consulta tarjetas participantes)';
                    }

                }
                if ( item.months === 1 ) {
                    data.readonly = false;
                }
                return data;
            } );
        },
        canApplyPaymentSchemas() {
            const FloatTotal = parseFloat( this.checkout.total );
            const minimumAmount = 300.0;
            return FloatTotal >= minimumAmount;
        },
        userIsUsingPlan() {
            return this.selectedMonth > 1;
        },
        floatMaxAmountAmex(){
            return parseFloat( this.envs.amexLimit );
        },
        floatMaxAmountInternationalCard() {
            return parseFloat( this.envs.LIMIT_FOR_INTERNATIONAL_CARDS );
        },
        amexAmountExceeded () {
            if ( this.permissions.unlimitedAmexAndBBVA ) {
                return false;
            }
            return ( this.isAmex || this.currentIssuer === 'BBVA' ) && this.floatAmount > this.floatMaxAmountAmex ;
        },
        fixedSubtotal() {
            return this.fixedDigits( this.subtotal );
        },
        descMensualidades() {
            if( this.checkout.preselectedPaymentPlan ){
                return !this.canApply || ( this.plans2.length == 1 && this.plans2[ 0 ].months === 1 ) ?
                    'Mensualidades no disponibles para tu tarjeta' : '';
            }
            else{
                return this.canApply ?
                    'Hasta 24 mensualidades' : 'Mensualidades no disponibles para tu tarjeta';
            }
        },
        getMessageForInternationalCards() {
            const messageToShow = this.envs.LIMIT_MESSAGE;
            return 'Tarjetas emitidas fuera de México '
              + messageToShow.replace( '{amount}', this.envs.LIMIT_FOR_INTERNATIONAL_CARDS  );
        },
        getAmexMessageForExceededAmount() {
            const messageToShow = this.envs.amexMessage;
            return 'American Express ' + messageToShow.replace( '{amount}', this.floatMaxAmountAmex );
        },
        getBBVAMessageForExceededAmount() {
            const messageToShow = this.envs.amexMessage;
            return 'BBVA ' + messageToShow.replace( '{amount}', this.floatMaxAmountAmex );
        },
        getIssuerAmountExceeded() {
            if ( this.currentIssuer === 'AMEX' ) {
                return this.getAmexMessageForExceededAmount;
            }
            else if ( this.currentIssuer === 'BBVA' ) {
                return this.getBBVAMessageForExceededAmount;
            }
            else if ( this.currentIssuer === 'INTERNATIONAL' ) {
                return this.getMessageForInternationalCards;
            }
            return '';
        },
        floatAmount() {
            return parseFloat( this.checkout.total );
        },
        internationalCardAmountExceeded() {
            if ( this.currentIssuer === 'INTERNATIONAL' && this.permissions.unlimitedInternational ) {
                return false;
            }
            return this.currentIssuer === 'INTERNATIONAL' && this.floatAmount > this.envs.LIMIT_FOR_INTERNATIONAL_CARDS;
        },
        color() {
            return this.user ? this.user.colorEntity : '';
        },
        isPAD() {
            return this.checkout.remote_payment;
        },
        c2pBrands() {
            return this.envs.c2pBrands;
        },
        c2pBrandsAsArray() {
            return this.envs.c2pBrands ? this.envs.c2pBrands.split( ',' ) : [];
        },
        c2pBrandsForOTP() {
            const allowedBrands = this.c2pBrandsAsArray.map( item => {
                if ( item === 'amex' ) {
                    return 'american-express'
                }
                return item;
            } );
            return allowedBrands;
        },
        showC2PUI() {
            if ( this.c2pInstanceError || !this.envs.SRC_APP_ID ) {
                return false;
            }
            const allowedUsers = this.envs.usersListC2pPilot ? this.envs.usersListC2pPilot.split( ',' ) : [];
            if ( this.envs.statusPilotTestForC2P && ( allowedUsers.includes( this.user.userId.toString() ) ||
                ( this.checkout.remote_payment && allowedUsers.includes( this.checkout.real_user_id.toString() ) ) ) ) { // just some merchants can see the C2P UI
                return true;
            } else if ( this.envs.enabledC2PForPAD && this.checkout.remote_payment ) {
                return true;
            } else if ( !this.checkout.remote_payment && this.envs.statusC2PForIntegrations ) {
                return true;
            }
            return false;
        },
        getInformationCardForC2P() {
            const card = this.c2pCards.find( item => item.srcDigitalCardId === this.currentCardId );
            return card;
        },
        existsValidCard() {
            return this.clientData.card && luhn.validate( this.clientData.card ) && !this.isAmex &&
              !this.currentCardIsVisa;
        },
        getCurrentMerchant() {
            if ( this.checkout.remote_payment ) {
                return this.checkout.externalId
                    ? this.checkout.externalId
                    : this.checkout.linkInformation.usernameRemotePayment;
            }
            return this.users.name;
        },
        getCurrentCardBrand() {
            if ( this.isAmex ) {
                return 'AMEX';
            }
            if ( this.currentCardIsVisa ) {
                return 'Visa';
            }
            if ( this.clientData.card && this.clientData.card.startsWith( '5' ) ) {
                return 'Mastercard';
            }
            return '';
        },
        currentCardIsVisa() {
            return this.clientData.card && this.clientData.card.startsWith( '4' );
        }
    },
    watch: {
        clientData: {
            deep: true,
            handler: function () {
                if ( this.clientData.card
                  && ( this.clientData.card.startsWith( '37' ) || this.clientData.card.startsWith( '34' ) ) ){
                    this.cardDigits = '#### - ###### - #####';
                    this.placeholderDigits = '****';
                    this.createC2pAccount = false;
                } else {
                    this.cardDigits = '#### - #### - #### - ####';
                    this.placeholderDigits = '***';
                }
            },
        },
        paymentTypeSelected: {
            handler: async function ( current, prev ) {
                if ( this.paymentTypeSelected === 'default' ) {
                    // if ( this.clientData.card.length <= 6 ) {
                    //     this.clientData.card = '';// was filled by the bin of c2p
                    // }
                    if ( !this.c2pCards.length > 0 ) {
                        this.showCheckboxToCreateAccount = true;
                    }
                    this.showPaymentForm = true;
                }
                if ( this.paymentTypeSelected === 'c2p' && this.c2pUserSigned ) {
                    this.showPaymentForm = false;
                }
            },
        },
        addingNewCardForC2P: {
            handler: function ( value ) {
                if ( !value ) {
                    this.newCardForC2p = {
                        card: '',
                        period: '',
                        cvv: '',
                    };
                    this.cvvC2p = '';
                }
            }
        },
        c2pUserSigned: {
            handler: function ( value ) {
                if ( !value ) {
                    this.createC2pAccount = true;
                } else {
                    this.createC2pAccount = false;
                }
            }
        },
    },
    async mounted() {
        this.tabSliderColor = window.innerWidth <= 600 ? 'white' : 'black';
        this.setTabHeight = window.innerWidth <= 600 ? '100' : 'auto';
        this.extraSmallWindow = window.innerWidth <= 600 && window.innerWidth > 330 ? 'justify-content: left' : '';
        window.lookingup = false;
        this.isLoading = true;
        let _user_id = this.user.userId.toString();
        if ( this.isPAD ) {
            _user_id = this.checkout.real_user_id.toString();
        }
        const element = document.querySelector( '#btnSubmit' );
        element.ondblclick = function( e ){
            return false;
        }
        const _sift = window._sift = window._sift || [];
        _sift.push( [ '_setAccount', this.siftBeaconKey ] );
        _sift.push( [ '_setUserId', _user_id ] );
        _sift.push( [ '_trackPageview' ] );

        ( function() {
            function ls() {
                const e = document.createElement( 'script' );
                e.src = 'https://cdn.sift.com/s.js';
                document.body.appendChild( e );
            }
            if ( window.attachEvent ) {
                window.attachEvent( 'onload', ls );
            } else {
                window.addEventListener( 'load', ls, false );
            }
        } )();
        const recaptchaScript = document.createElement( 'script' );
        recaptchaScript.async = true;
        recaptchaScript.defer = true;
        recaptchaScript.setAttribute( 'src', `https://www.google.com/recaptcha/api.js?render=${ this.envs.VUE_RECAPTCHA_KEY }` );
        document.head.appendChild( recaptchaScript );
        if ( this.isPAD ) {
            const googleTagManagerScript = document.createElement( 'script' );
            const googleTagManagerNoScript = document.createElement( 'noscript' );
            googleTagManagerScript.async = true;
            googleTagManagerNoScript.async = true;
            googleTagManagerScript.defer = true;
            googleTagManagerNoScript.defer = true;
            googleTagManagerScript.type = 'text/javascript';
            googleTagManagerNoScript.type = 'text/javascript';
            if ( this.envs.addTagManager ) {
                googleTagManagerScript.text = `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-PQLMWZD');`;
                googleTagManagerNoScript.text = `<iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PQLMWZD"
    height="0" width="0" style="display:none;visibility:hidden"></iframe>`;
            } else {
                googleTagManagerScript.text = "console.log('GTM must be added :D')";
            }
            document.head.appendChild( googleTagManagerScript );
            document.body.appendChild( googleTagManagerNoScript );
        }
        if ( this.showC2PUI && !this.envs.hideC2P ) {
            await this.verifyC2PAccountByCookies();
        } else {
            this.createC2pAccount = false;
        }
        this.isLoading = false;
    },
    methods:{
        async sendInformation(){
            this.makingApiCall = true;
            if ( !this.isPAD ) {
                await this.verifyChanges();
            }
            await this.makeValidations();
            if ( this.paymentTypeSelected === 'c2p' && this.addingNewCardForC2P
              && this.$refs.clickToPayForm.validate() ) {
                await this.createClickToPayAccount( 'add' );
            }
            else if ( this.paymentTypeSelected === 'c2p' && this.currentCardId ) {
                if ( this.$refs.cvvC2pForm.validate() ) {
                    await this.startTransactionWithCard();
                }
            }
            else {
                if ( this.$refs.paywithForm.validate() ) {
                    if ( !this.c2pUserSigned && this.createC2pAccount ){ // user set payment card but wants to create a c2p accout
                        const existsOnSRCI = await this.userExistsOnSRCI();
                        if ( !existsOnSRCI ) {
                            await this.createClickToPayAccount();
                        }
                    } else {
                        await this.sendToPaywithService();
                    }
                }
            }
            this.makingApiCall = false;
        },
        async sendToPaywithService() {
            this.letsRedirect();
            await this.processCheckout()
        },
        async processTokenized() {
            const redirectTo = this.checkout.remote_payment ? 'pay' : 'checkout';
            try {
                const token = await this.verifyRecaptcha();
                const { data } = await this.$axios.post( `${ this.serviceApi }/click2pay/${ this.orderId }`, {
                    ...self.clientData,
                    cvvC2p: ( this.cvvC2p || '' ).trim(),
                    recaptcha: token,
                    mastercardCheckout: this.masterCardCheckout,
                    paymentType: this.paymentTypeSelected,
                    payment_method: this.clientData.payment_method,
                    typeMonthlyPayment: this.clientData.typeMonthlyPayment,
                    userId: this.checkout.remote_payment ? this.checkout.real_user_id : this.user.userId,
                } );
                if ( data.success && data.allowRedirect ) {
                    window.location.href= `/success/${ this.orderId }`;
                } else if ( data.success && data.htmlEntity ) {
                    if ( data.IsoResponseCode ) {
                        window.document.write( data.htmlEntity );
                    } else {
                        this.htmlEntity = data.htmlEntity;
                        setTimeout( () => {
                            document.frmHtmlCheckout.submit()
                        }, 500 )
                    }

                } else {
                    this.cancelRedirect();
                    if ( data.customPADMessage ) {
                        this.$nuxt.error( {
                            message: data.customPADMessage.message,
                            statusCode: data.customPADMessage.code,
                            errorCode: data.customPADMessage.code,
                            callbackUrl: `/${ redirectTo }/${ this.orderId }`,
                        } )
                    } else {
                        this.$nuxt.error( {
                            message: data.message,
                            statusCode: data.statusCode,
                            errorCode: data.statusCode,
                            callbackUrl: `/${ redirectTo }/${ this.orderId }`,
                        } )
                    }
                }
            } catch ( err ) {
                this.cancelRedirect();
                const statusCode = 500;
                this.$nuxt.error( {
                    message: 'Ha surgido un error, por favor vuelve a intentarlo.',
                    statusCode: statusCode,
                    errorCode: statusCode,
                    callbackUrl: `/${ redirectTo }/${ this.orderId }`,
                } )
            }
        },
        async processCheckout() {
            const redirectTo = this.checkout.remote_payment ? 'pay' : 'checkout';
            try {
                const self = this;
                const token = await self.verifyRecaptcha();
                const { data } = await this.$axios
                    .post( `${ this.envs.validateTxnUrl }${ this.orderId }`, {
                        ...self.clientData,
                        masterCardCheckout: this.masterCardCheckout,
                        recaptcha: token,
                        paymentType: this.paymentTypeSelected,
                        userId: this.checkout.remote_payment ? this.checkout.real_user_id : this.user.userId
                    } );
                if ( data.success && data.htmlEntity && data.htmlEntity !== ''
                  && this.envs.threeDsVersionToBeUser === 1 ) {
                    this.htmlEntity = data.htmlEntity
                    setTimeout( () => {
                        document.frmHtmlCheckout.submit()
                    }, 500 )
                }
                else if ( data.htmlEntity && data.htmlEntity !== ''
                  && this.envs.threeDsVersionToBeUser === 2 ) {
                    window.document.write( data.htmlEntity );
                }
                else if ( data.success && data.allowRedirect ) {
                    window.location.href= `/success/${ this.orderId }`;
                } else {
                    this.cancelRedirect();
                    if ( data.customPADMessage ) {
                        this.$nuxt.error( {
                            message: data.customPADMessage.message,
                            statusCode: data.customPADMessage.code,
                            errorCode: data.customPADMessage.code,
                            callbackUrl: `/${ redirectTo }/${ this.orderId }`,
                        } )
                    } else {
                        this.$nuxt.error( {
                            message: data.message,
                            statusCode: '',
                            errorCode: '',
                            callbackUrl: `/${ redirectTo }/${ this.orderId }`,
                        } )
                    }
                }

            } catch ( err ) {
                if ( err.response && err.response.status === 400 ) {
                    this.$nuxt.error( {
                        message: this.envs.VUE_BP_RISK_ERROR,
                        statusCode: this.envs.VUE_BP_RISK_CODE,
                        errorCode: this.envs.VUE_BP_RISK_CODE,
                        callbackUrl: `/${ redirectTo }/${ this.orderId }`,
                    } )
                } else {
                    this.$nuxt.error( {
                        message: 'Ha surgido un error, por favor vuelve a intentarlo.',
                        statusCode: 500,
                        errorCode: 500,
                        callbackUrl: `/${ redirectTo }/${ this.orderId }`,
                    } )
                }

            }
            this.makingApiCall = false;
        },
        makeValidations() {
            this.rules =  {
                required: value => !!value || 'Campo Requerido.',
                strings: value =>
                    /^[a-zA-ZÀ-ú ]+$/.test( value ) || 'Solo se permiten letras y tildes.',
                isValidCard: value =>
                    luhn.validate( value ) || 'Debe introducir una tarjeta valida.',
                isValidExpDate: value => validExpDate( value ),
                emailRules: [
                    v => !!v || 'Correo es requerido.',
                    // eslint-disable-next-line max-len
                    v => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( v ) || 'El correo debe ser válido.'
                ],
                phoneRules: v => !!v || 'El teléfono es requerido',
                isAmex: [
                    v => !!v || 'Campo Requerido.',
                    v => v ?  v.length >= 3 || 'El cvv debe contener al menos 3 dígitos.' : ''
                ]
            }
            if ( this.isAmex ) {
                this.rules.isAmex = [
                    v => !!v || 'Campo Requerido.',
                    v => v ?  v.length === 4 || 'El cvv debe ser de 4 dígitos.' : ''
                ]
            }
            if ( this.isPAD || this.isAmex ) {
                this.rules.lastname = [
                    v => !!v || 'Campo Requerido',
                ]
            }
            if ( this.isPAD || ( !this.isPAD && !this.user.disabledSiftForm ) ) {
                this.rules.cardholderEmail = [
                    v => !!v || 'E-mail es requerido',
                    // eslint-disable-next-line max-len
                    v => /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test( v ) || 'El correo debe ser válido.'
                ];
                this.rules.cardholderPhone = [
                    v => !!v || 'El teléfono es requerido',
                ]
            }
        },
        letsRedirect(){
            this.redirectDialog = true;
            this.redirectFlag = true;
        },
        cancelRedirect(){
            this.redirectFlag = false;
            this.redirectDialog = false;
        },
        verifyChanges() {
            if ( !this.isPAD ) {

                const name = document.querySelector( '#name' ).value;
                const card = document.querySelector( '#card' ).value;
                const period = document.querySelector( '#period' ).value;
                const cvv = document.querySelector( '#cvv' ).value;

                if( this.clientData.name === '' && name !== '' ){
                    this.clientData.name = name;
                }
                if( this.clientData.card === null && card !== '' ){
                    this.clientData.card = card;
                }
                if( this.clientData.period === null && period !== '' ){
                    this.clientData.period = period;
                }
                if( this.clientData.cvv === null && cvv !== '' ){
                    this.clientData.cvv = cvv;
                }
                const userEmail = document.querySelector( '#useremail' ).value;
                const userPhone = document.querySelector( '#userphone' ).value;
                if( this.clientData.email === '' && userEmail !== '' ){
                    this.clientData.email = userEmail;
                }
                if( this.clientData.phone === '' && userPhone !== '' ){
                    this.clientData.phone = userPhone;
                }
            }
        },
        showBanks() {
            this.dialogForBanks = true;
        },
        onShowC2PInformation() {
            this.showDialogClickToPayInformation = true;
        },
        handlerCloseModal() {
            this.dialogForBanks = false;
            this.showC2PCardList = false;
            this.showOtpValidation = false;
            this.showDialogClickToPayInformation = false;
        },
        handlerRetriesExceeded() {
            setTimeout( () => {
                this.showOtpValidation = false;
                this.paymentTypeSelected = 'default';
            }, 3000 );
        },
        changeOtp( conf ) {
            this.otpConf.maskedValidationChannel = conf.maskedValidationChannel;
            this.initiateValidation( conf.validationChannelId );
        },
        onChange() {
            this.clientData.payment_method = this.selectedMonth;
            if ( this.selectedMonth !== 1 ) {
                const planWasFound = this.plans2.find( item => item.months === this.selectedMonth );
                if ( planWasFound ) {
                    this.clientData.typeMonthlyPayment = planWasFound.type;
                    this.subtotal = planWasFound.realAmount;
                }
            } else {
                this.clientData.typeMonthlyPayment = '';
            }
        },
        async onBlurWithBinOfCard( ) {
            await this.onBlur( this.clientData.card );
        },
        async onBlur( card ) {

            const self = this;
            this.atLeastOneBlur = true;
            if ( card === '' || card === null || this.plans.length === 0 ) {
                this.selectedMonth = 1;
                this.canApply = false;
                this.clientData.payment_method = 1;
            }
            else if( ( card !== ''
            && self.canApplyPaymentSchemas && luhn.validate( card ) )
              || this.paymentTypeSelected === 'c2p' ) {
                self.clientData.payment_method = 1;
                self.showMSI = true;
                self.canApply = false;
                this.currentIssuer = '';
                try {
                    const { data } = await this.$axios
                        .post( `${ this.serviceApi }/bin/validate`, { card } );
                    const plansMany = this.plans.length > 1;
                    if ( data.validated ) {
                        this.canApply = true;
                    }
                    this.plans2 = [];
                    if ( this.checkout.preselectedPaymentPlan ) {
                        const includePlan = data.plans.includes(
                            this.plans[ plansMany ? 1 : 0 ].months );
                        if( !plansMany && this.plans[ 0 ].months > 1 && !includePlan ) {
                            this.plans2.push(
                                {
                                    'realAmount': this.checkout.total,
                                    'months':1,
                                    'amountPerMonth': this.checkout.total
                                }
                            );
                        }
                        else{
                            this.plans2.push( this.plans [ this.canApply && includePlan && plansMany ? 1 : 0 ] );
                        }
                        self.selectedMonth = this.plans2[ 0 ].months;
                        self.onChange();
                    }
                    else{
                        this.plans2 = this.plans;
                        if ( !this.plans2.find( item => item.months === 1 ) ){
                            this.plans2.unshift(
                                {
                                    'realAmount': this.checkout.total,
                                    'months':1,
                                    'amountPerMonth': this.checkout.total
                                }
                            );
                        }
                        self.selectedMonth = {
                            text: `${ this.plans2[ 0 ].months } ${ this.plans2[ 0 ].months > 1 ? 'Pagos' : 'Pago' } de
                            ${ this.plans2[ 0 ].amountPerMonth }`,
                            month: this.plans2[ 0 ].months,
                            readonly: false
                        }
                    }
                    if ( data.plans && data.plans.length > 0 ) {
                        self.availablePLans = data.plans;
                    }
                    if ( data.canUseDigitalWallet ) {
                        this.showCustomBanner = data.canUseDigitalWallet.canUseDigitalWallet;
                    }
                    if ( this.isAmex ) {
                        this.currentIssuer = 'AMEX';
                    }
                    else if ( data.canUseDigitalWallet &&  data.canUseDigitalWallet.issuer === 'BANCOMER' ) {
                        this.currentIssuer = 'BBVA';
                    }
                    else if ( data.isInternationalCard ) {
                        this.currentIssuer = 'INTERNATIONAL';
                    }
                } catch( error ) {
                    //
                }
            }
        },
        async onBlurForEmail( e ) {
            if ( !window.lookingup && !this.c2pUserSigned && this.showC2PUI ) {
                window.lookingup = true;
                await this.verifyC2pAccountWithEmailOrPhone( );
                window.lookingup = false;
            }
        },
        async onBlurForPhone() {
            if ( !window.lookingup && !this.c2pUserSigned && this.showC2PUI ) {
                window.lookingup = true;
                await this.verifyC2pAccountWithEmailOrPhone( 'phone' );
                window.lookingup = false;
            }
        },
        getAmountWithCommas( amount ) {
            return this.fixedDigits( amount );
        },
        verifyRecaptcha() {
            const self = this;
            return new Promise( resolve =>  {
            // eslint-disable-next-line no-undef
                grecaptcha.ready( function() {
                // eslint-disable-next-line no-undef
                    grecaptcha.execute( self.envs.VUE_RECAPTCHA_KEY ,
                        { action: 'ecommerce' } ).then( function( token ) {
                        resolve( token );
                    } );
                } );
            } );
        },
        async startTransactionWithCard() {
            this.showConfirmation = true;
            const iframeToShowForm = this.getAWindowForClickToPay();
            try {
                const informationCard = {
                    srcDigitalCardId: this.currentCardId,
                    windowRef: iframeToShowForm.contentWindow,
                };
                this.displayLogsWithTag( 'BP checkoutWithCard!', informationCard );
                const enrollment = await window.c2pInstance.checkoutWithCard( informationCard );
                this.masterCardCheckout = enrollment;
                this.displayLogsWithTag( 'BP result checkoutWithCard!', enrollment );
                if ( enrollment.checkoutActionCode === 'COMPLETE' ) {
                    await this.processTokenized();
                }
                else if ( enrollment.checkoutActionCode === 'SWITCH_CONSUMER' ) {
                    await this.signOutClickToPay();
                }
                else if ( enrollment.checkoutActionCode === 'ADD_CARD' ) {
                    this.addingNewCardForC2P = true;
                }
                else if ( enrollment.checkoutActionCode === 'CHANGE_CARD' ) {
                    await this.getCardsFromSRCI();
                }
                this.removeViewForClickToPay();
                this.showConfirmation = false;
            } catch( error ) {
                this.displayLogsWithTag( 'c2p Error', error );
                this.showDefaultErrorForClick2Pay();
                this.removeViewForClickToPay();
                this.showConfirmation = false;
            }
            this.showConfirmation = false;

        },
        async displayLogsWithTag( tag, message ) {
            if ( this.envs.showErrorsForC2P ) {
                console.log( `[${ tag }]`, message );
            }
        },
        async userExistsOnSRCI( params ) {
            try {
                this.isLoading = true;
                const result = await window.c2pInstance.idLookup( params );
                this.isLoading = false;
                return result.consumerPresent;
            } catch( error ) {
                this.displayLogsWithTag( 'idLookup', error );
                this.isLoading = false;
                this.showDefaultErrorForClick2Pay();
            }
            return false;
        },
        async verifyC2pAccountWithEmailOrPhone( lookFor = 'email' ) {
            const params = {};
            if ( this.clientData.email && lookFor == 'email' ) {
                params.email = this.clientData.email;
                try {
                    const userHasC2PAccount = await this.userExistsOnSRCI( params );
                    if ( userHasC2PAccount ) {
                        await this.initiateValidation();
                        return true;
                    }
                    return false;
                } catch ( error ) {
                    this.displayLogsWithTag( 'idLookup', error );
                }
            }
            if ( this.clientData.phone && lookFor == 'phone' ) {
                params.mobileNumber = {
                    countryCode: '52',
                    phoneNumber: this.clientData.phone,
                }
                try {
                    const userHasC2PAccount = await this.userExistsOnSRCI( params );
                    if ( userHasC2PAccount ) {
                        await this.initiateValidation();
                        return true;
                    }
                    return false;
                } catch ( error ) {
                    this.displayLogsWithTag( 'idLookup', error );
                }
            }
            return false;
        },
        async createClickToPayAccount( type = 'new' ) {
            this.showConfirmation = true;
            let newCard = {
                primaryAccountNumber: this.clientData.card,
                panExpirationMonth: this.clientData.period ? this.clientData.period.substring( 0,2 ) : '',
                panExpirationYear: this.clientData.period ? this.clientData.period.substring( 2,4 ) : '',
                cardSecurityCode: this.clientData.cvv,
                cardholderFirstName: this.clientData.name,
                cardholderLastName: this.clientData.lastname,
            }
            if ( type === 'add' ) { // user is trying to add a new card to its c2p account
                newCard = {
                    primaryAccountNumber: this.newCardForC2p.card,
                    panExpirationMonth: this.newCardForC2p.period.substring( 0,2 ),
                    panExpirationYear: this.newCardForC2p.period.substring( 2,4 ),
                    cardSecurityCode: this.newCardForC2p.cvv,
                }
                this.cvvC2p = this.newCardForC2p.cvv;
            } else {
                this.cvvC2p = this.clientData.cvv;
            }
            try {
                const card = await window.c2pInstance.encryptCard( newCard );
                const iframeToShowForm = this.getAWindowForClickToPay();
                const cardInformation = {
                    encryptedCard: card.encryptedCard,
                    cardBrand: card.cardBrand,
                    consumer: {
                        firstName: this.clientData.name,
                        lastName: this.clientData.lastname,
                        emailAddress: this.clientData.email,
                        mobileNumber: {
                            countryCode: '52',
                            phoneNumber: this.clientData.phone,
                        },
                    },
                    windowRef: iframeToShowForm.contentWindow,
                };
                if ( type === 'add' ) {
                    delete cardInformation.consumer;
                }
                const enrollment = await window.c2pInstance.checkoutWithNewCard( cardInformation );
                if ( enrollment.checkoutActionCode === 'COMPLETE' ) {
                    this.masterCardCheckout = enrollment;
                    this.removeViewForClickToPay();
                    this.showConfirmation = false;
                    await this.processTokenized();
                }
                else if ( enrollment.checkoutActionCode === 'SWITCH_CONSUMER' ) {
                    await this.signOutClickToPay();
                }
                else if ( enrollment.checkoutActionCode === 'ADD_CARD' ) {
                    this.addingNewCardForC2P = true;
                }
                else if ( enrollment.checkoutActionCode === 'CHANGE_CARD' ) {
                    await this.getCardsFromSRCI();
                }
                else {
                    this.removeViewForClickToPay();
                    this.showConfirmation = false;
                }
            } catch( error ) {
                this.displayLogsWithTag( 'encryptCard', error );
                this.removeViewForClickToPay();
                this.showDefaultErrorForClick2Pay();
                this.showConfirmation = false;
            }

        },
        async handlerOptValue( cards ) {
            try {
                this.c2pCards = cards;
                this.setCardsAndListener( cards );
                this.updateUIForClickToPay();
                this.paymentTypeSelected = 'c2p';

            } catch( error ) {
                this.showDefaultErrorForClick2Pay();
            }
        },
        updateUIForClickToPay() {
            if ( this.c2pCards.length > 0 ) {
                this.c2pUserSigned = true;
                this.showPaymentForm = false;
                this.showCheckboxToCreateAccount = false;
                this.onBlur( this.c2pCards[ 0 ].panBin );
            } else {
                this.c2pUserSigned = false;
                this.showPaymentForm = true;
                this.showCheckboxToCreateAccount = true;
            }
        },
        async initiateValidation( channelId = null ) {
            try {
                let otpConf = null;
                if ( channelId ) {
                    otpConf = await window.c2pInstance.initiateValidation(
                        { requestedValidationChannelId: channelId } );
                } else {
                    otpConf = await window.c2pInstance.initiateValidation();
                }
                this.otpConf = otpConf;
                this.showOtpValidation = true;
            } catch ( error ) {
                this.displayLogsWithTag( 'idLookup', error );
            }

        },
        showDefaultErrorForClick2Pay() {
            this.click2PayError = 'Ha surgido un error, por favor vuelve a intentarlo';
            setTimeout( () => {
                this.click2PayError = '';
            }, 3000 );
        },
        getAWindowForClickToPay() {
            const container = document.querySelector( '#divToInsertIframe' );
            const iframeToShowForm = document.createElement( 'iframe' );
            iframeToShowForm.setAttribute( 'id', 'paymentWindow' );
            iframeToShowForm.setAttribute( 'style', 'height:100%;width:100%;' );
            container.appendChild( iframeToShowForm );
            return iframeToShowForm;
        },
        removeViewForClickToPay() {
            try {
                const currentIframe = document.querySelector( '#paymentWindow' );
                currentIframe.remove();
            } catch ( err ) {
                //
            }
        },
        setCardsAndListener( cards ) {
            const self = this;
            setTimeout( () => {
                const srcCardList = document.querySelector( '#srcCardList' );
                srcCardList.loadCards( cards );
                document.querySelector( 'src-card-list' ).addEventListener( 'selectSrcDigitalCardId', event => {
                    self.currentCardId = event.detail;
                    self.onBlur( self.getInformationCardForC2P.panBin );
                } );
                document.querySelector( 'src-card-list' ).addEventListener( 'clickAddCardLink', event => {
                    self.cvvC2p = '';
                    self.addingNewCardForC2P = true;
                } );
                document.querySelector( 'src-card-list' ).addEventListener( 'clickSignOutLink', async event => {
                    await self.signOutClickToPay();
                } );
            }, 100 )
        },
        async signOutClickToPay() {
            try {
                this.isLoading = true;
                await window.c2pInstance.signOut();
                this.c2pCards = [];
                const srcCardList = document.querySelector( '#srcCardList' );
                srcCardList.loadCards( [] );
                this.active = 1;
                this.paymentTypeSelected = 'default';
            } catch ( err ) {
                this.displayLogsWithTag( 'signOut error', err );
            } finally {
                this.isLoading = false;
            }
        },
        async verifyC2PAccountByCookies() {
            try {
                // eslint-disable-next-line no-undef
                window.c2pInstance = new Click2Pay();
                const c2pbp = new ClickToPayBP();
                const dpaData = {
                    dpaPresentationName: this.envs.dpaPresentationName,
                    dpaName: this.envs.dpaName,
                }
                const defaultConf = c2pbp.getDefaultConf(
                    this.checkout.total,
                    this.c2pBrandsAsArray,
                    this.envs.c2PDynamicDataType,
                    dpaData );
                defaultConf.srcDpaId = this.envs.SRC_APP_ID;
                await window.c2pInstance.init( defaultConf );
                await this.getCardsFromSRCI();
            } catch( err ) {
                this.c2pInstanceError = err;
                this.createC2pAccount = false;
            }
            document.querySelector( '#c2p-bg' ).addEventListener( 'click', ( e ) => {
                this.showConfirmation = false;
                this.removeViewForClickToPay();
                this.makingApiCall = false;
            } );
        },
        async getCardsFromSRCI() {
            const cards = await window.c2pInstance.getCards();
            if ( cards && cards.length > 0 ) {
                this.createC2pAccount = false;
                this.c2pCards = cards;
                this.currentCardId = cards[ 0 ].srcDigitalCardId;
                this.setCardsAndListener( cards );
                this.paymentTypeSelected = 'c2p';
                this.active = 1;
                this.updateUIForClickToPay();
            }
        },
        onChangePaymentOption( event ) {
            if ( event === 0 ) {
                this.paymentTypeSelected = 'default';
                this.createC2pAccount = false;
            }
            if ( event === 1 ) {
                this.paymentTypeSelected = 'c2p';
                if ( !this.c2pUserSigned ) {
                    this.createC2pAccount = true;
                }
            }
        },
        smallWindow() {
            return this.$vuetify.breakpoint.xs;
        }
    },
}
</script>

<style scoped>
.items-container-scroll{
    max-height: 40vh;
    overflow-y: auto;
    border: dashed 0.1em #CED1CF;
    border-radius: 0.3em;
    /* background-color: #F9FCFF; */
}
.payment-window-bg {
  width: 100%;
  height: 100%;
  position: fixed;
  opacity: 0.5;
  background-color: black;
  right: 0;
  top: 0;
  z-index: 100;
}
.payment-window{
    position: fixed;
    min-width: 400px;
    height: 100%;
    z-index: 100;
    top: 0;
    right: -400px;
    background: white;
    transition: right 0.5s ease-in-out;
}
.payment-active {
  right: 0;
}
#paymentWindow {
  width: 100%;
  height: 100%;
}
iframe{
  display: block;
  vertical-align: middle;
}
#checkedc2p {
  width: 15px;
  height: 15px;
}
.card-box {
  overflow-y: scroll !important;
  max-height: 300px;
}
.c2p-img-create-account {
  height: 17px !important;
}

</style>
