<template>
  <VFlex mt-4>
    <VLayout
      align-center justify-center
      row fill-height
    >
      <VFlex
        xl10 md11 sm12
      >
        <VCard>
          <div
            class="pa-2" :style="`background-color: ${color}`"
          />
          <VLayout
            align-center justify-center row
            wrap fill-height pa-5
            class="text-xs-center"
          >
            <VFlex>
              <img
                src="~/static/load.gif" alt="waiting" 
              >
              
              <p class="headline font-weight-medium">
                Espere un momento, su pago se está procesando
              </p>
              
              <p class="subheading mb-1 mt-4 grey--text">
                Compra
              </p>
              <p class="headline font-weight-medium">
                {{ externalId }}
              </p>   
             
              <p class="subheading mb-1 mt-4 grey--text">
                Total
              </p>
              <p class="headline font-weight-medium">
                {{ total | currency }}
              </p>
            </VFlex>
          </VLayout>
        </VCard>
      </VFlex>
    </VLayout>
  </VFlex>
</template>

<script>
export default {
    name: 'LoaderCard',
    props: {
        color: { type: String, required:true },
        externalId: { type: String, required:true },
        total: { type: String, required:true }
    }
}
</script>