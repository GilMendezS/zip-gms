<template>
  <span>
    <img
      src="@/assets/clicktopay.svg" :height="defaultheight"
      alt="clicktopay"
    >
    <img
      src="@/assets/pipe.svg" :height="defaultheight"
      alt="pipe"
    >
    <img 
      v-for="brand in currentBrands"
      :key="brand"
      :height="defaultheight"
      :src="require( '@/assets/'+brand+'.svg' )" :alt="brand"
    >
  </span>
</template>
<script>
export default {
    props: {
        brands: { type: Array, default: () => [ 'mastercard', 'visa' ] }
    },
    data: () => ( {
        defaultheight: 30,
    } ),
    computed: {
        currentBrands() {
            const validBrands = [ 'mastercard' , 'visa', 'amex' ];
            return this.brands.filter( item => validBrands.includes( item ) );
        }
    } 
}
</script>