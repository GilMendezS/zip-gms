<template>
  <VDialog
    v-model="isOpen"
    :persistent="persistent"
    no-click-animation
    max-width="400px"
  >
    <VCard class="pl-3">
      <VCardTitle>
        <h1 class="modalTitle">
          Te damos la bienvenida a <span class="orange-click-to-pay-color">Click to Pay</span>
        </h1>
      </VCardTitle>
      <VCardText>
        <p class="">
          Un método de pago rápido y seguro que aceptan Mastercard, Visa y American Express.
        </p>
        <ClickToPayBrands :brands="brands" />
        <ul>
          <li> <span>Úsalo en comercios de todo el mundo</span> </li>
          <li> <span>Protege tu información en un perfil seguro</span> </li>
          <li><span> Configúralo una sola vez para hacer pagos fácilmente en el futuro </span></li>
        </ul>
        <VBtn
          round
          large
          class="black white--text c2p-accept-btn mt-4"
          @click="sendEventToCloseModal"
        >
          OK
        </VBtn>
      </VCardText>
    </VCard>
  </VDialog>
</template>
<script>
import ClickToPayBrands from '@/components/project/ClickToPayBrands.vue';

export default {
    components: {
        ClickToPayBrands,
    },
    props: {
        isOpen: { type: Boolean },
        brands: { type: Array, required: true, default: () => [] }
    },
    data: () => ( {
        persistent: true,
    } ),
    mounted() {
    },
    methods: {
        sendEventToCloseModal() {
            this.$emit( 'closeModal' );
        },
    },
}
</script>
<style scoped>
.c2p-accept-btn {
    width: 90%;
}
ul {
    margin-top: 10px;
    margin-left: 0;

}
ul > li {
    margin-top: 15px;
}
li span {
    position: relative;
    left: 15px;
}
.orange-click-to-pay-color {
    color: rgb( 255, 43, 17 )
}
</style>