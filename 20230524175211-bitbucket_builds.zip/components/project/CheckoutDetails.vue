<template>
  <div v-if="!checkout.remote_payment">
    <p class="title">
      <VIcon :color="color" class="mr-3">
        shopping_cart
      </VIcon>
      Compra #{{ checkout.externalId }}
    </p>

    <VList
      subheader dense class="items-container-scroll py-3"
    >
      <VSubheader>Artículos</VSubheader>

      <VListTile v-for="(item, $index) in checkout.items" :key="$index">
        <VListTileContent>
          <VListTileTitle> {{ item }}</VListTileTitle>
        </VListTileContent>
      </VListTile>
    </VList>

    <p class="subheading mb-1 mt-4 grey--text text-xs-center">
      Total
    </p>
    <p class="title text-xs-center">
      {{ checkout.total | currency }}
    </p>
  </div>
  <div v-else>
    <div class="box">
      <div>
        <p class="text-xs-center text-md-left">
          {{ checkout.externalId }}
        </p>
        <!--p class="text-xs-center text-md-left">
        </p-->
      </div>
    </div>
    <p class="rp-subheader mb-1 mt-4 text-xs-center text-md-left">
      Mensaje:
    </p>
    <p class="mb-4 text-xs-center text-md-left">
      {{ checkout.description }}
    </p>
    <p class="rp-subheader remove-spacing text-xs-center text-md-left">
      Total a enviar (MXN)
    </p>
    <p class="text-xs-center text-md-left">
      <span class="text-grey text-xs-center text-md-left">$</span>
      <span class="price-text text-xs-center text-md-left">{{ checkout.total }}</span>
    </p>
  </div>
</template>
<script>
export default {
    props: {
        checkout: {
            type: Object, default:() => ( {} ),
        },
        color: { type: String, required: true }
    }
}
</script>
<style>
  .items-container-scroll{
      max-height: 40vh;
      overflow-y: auto;
      border: dashed 0.1em #CED1CF;
      border-radius: 0.3em;
  }
</style>
