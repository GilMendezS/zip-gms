<template>
  <VDialog
    v-model="isOpen"
    :persistent="persistent"
    max-width="350px"
  >
    <no-ssr>
      <src-otp-input
        v-show="otpConf && !showAlternativeChannels"
        id="src-otp-input" locale="es_MX"
        :card-brands="brands" display-cancel-option="true"
        :error-reason="errorReason"
        :masked-identity-value="otpConf.maskedValidationChannel" :network-id="otpConf.network" type=""
        display-header="true"
        auto-submit="true"
        show-continue-another-way="false"
      />
      <src-otp-channel-selection
        v-show="showAlternativeChannels"
        id="src-otp-channel-selection" locale="es_MX"
        :card-brands="brands" display-cancel-option="true" type=""
        display-header="true"
      />
    </no-ssr>
  </VDialog>
</template>
<script>

export default {
    props: {
        isOpen: { type: Boolean },
        otpConf: { type: Object, default: () => { } },
        brands: { type: Array, required: true, default: () => [] }
    },
    data: () => ( {
        persistent: true,
        showAlternativeChannels: false,
        currentCode: '',
        errorReason: '',
    } ),
    mounted() {
        const self = this;
        setTimeout( () => {
            const srcOtpChannelSelection = document.querySelector( 'src-otp-channel-selection' );
            // set valid otp channels
            srcOtpChannelSelection.identityValidationChannels = this.otpConf.supportedValidationChannels || [];
            const srcOtpInput = document.querySelector( 'src-otp-input' );
            // add events for posible actions
            srcOtpInput.addEventListener( 'close', ( e ) => {
                self.$emit( 'closeModal' );
            } );
            srcOtpChannelSelection.addEventListener( 'close', ( e ) => {
                self.$emit( 'closeModal' );
            } );
            srcOtpInput.addEventListener( 'continue', ( { detail } ) => {
                this.errorReason = '';
                window.c2pInstance.validate(
                    {
                        value: this.currentCode,
                    }
                ).then( cards => {
                    this.$emit( 'otpValue', cards );
                    this.currentCode = '';
                    this.$emit( 'closeModal' );
                } )
                    .catch( err => {
                        if ( err.reason && err.reason === 'ACCT_INACCESSIBLE' ) {
                            this.errorReason = 'RETRIES_EXCEEDED';
                            this.$emit( 'onRetriesExceeded' );
                        } else {
                            this.errorReason = 'CODE_INVALID';
                        }
                    } )
            } );
            srcOtpInput.addEventListener( 'otpChanged', ( { detail } ) => {
                if ( detail !== null ) {
                    this.currentCode = detail;
                }
            } );
            srcOtpInput.addEventListener( 'alternateRequested', ( e ) => {
                this.showAlternativeChannels = true;
            } );
            srcOtpChannelSelection.addEventListener( 'continue', function ( { detail } ) {
                self.errorReason = '';
                // user has decided to continue without 'click to pay'
                if ( detail.identityType == 'GUEST' ) {
                    self.$emit( 'closeModal' );
                } else {
                    self.setNewOtp( detail );
                    self.showAlternativeChannels = false;
                }

            } );

        }, 500 );
    },
    methods: {
        sendEvent() {
            this.$emit( 'closeModal' );
        },
        setNewOtp( conf ) {
            this.$emit( 'changeOtp', conf );
        }
    },
}
</script>
<style scoped>
</style>
