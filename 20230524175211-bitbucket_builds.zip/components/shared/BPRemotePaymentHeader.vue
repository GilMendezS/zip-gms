<template>
  <VFlex my-3>
    <VLayout
      align-start justify-center
      row fill-height
    >
      <VFlex class="text-xs-center">
        <div v-show="logoLoaded">
          <img
            src="~/assets/pago_distancia.png" height="120"
            class="mb-2"
            @load="logoLoaded = true"
          >
        </div>
      </VFlex>
    </VLayout>
  </VFlex>
</template>

<script>
export default {
    name: 'BPRemotePaymentHeader',
    data() {
        return {
            logoLoaded: false
        }
    }
}
</script>
