<template>
  <VLayout
    align-center justify-center
    row fill-height mt-5
  >
    <VFlex
      xl6 md6
      sm12
    >
      <p class=" blue-grey--text text-xs-center">
        Pago procesado de manera segura con:
      </p>

      <VLayout
        row
        wrap
        align-center
        justify-center
        fill-height
        class="text-xs-center"
      >
        <VFlex mt-4 mx-4>
          <img
            src="~/assets/mc_sc.svg" alt="mastercard"
            height="50"
          >
        </VFlex>
        <VFlex mt-4 mx-4>
          <img
            src="~/assets/bp.png" alt="bp-logo"
            height="30"
          >
        </VFlex>

        <VFlex mt-4 mx-4>
          <img
            src="~/assets/verified_visa.svg" alt="visa"
            height="40"
          >
        </VFlex>
      </VLayout>
    </VFlex>
  </VLayout>
</template>

<script>
export default {
    name: 'BPFooter'
}
</script>
