<template>
  <div class="vld-parent">
    <Loading
      :active="isLoading"
      :can-cancel="false"
      :is-full-page="fullPage"
      :color="color"
      :opacity="opacity"
    />
  </div>
</template>

<script>
import Loading from 'vue-loading-overlay';
import 'vue-loading-overlay/dist/vue-loading.css';

export default {
    components: {
        Loading
    },
    props: {
        isLoading: {
            type: Boolean
        }
    },
    data() {
        return {
            fullPage: true,
            opacity: 0.6,
            color: '#019cde'
        }
    },
    methods: {
    },
}
</script>