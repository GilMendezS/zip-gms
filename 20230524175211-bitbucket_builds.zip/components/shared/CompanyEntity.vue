<template>
  <VFlex my-3>
    <VLayout
      align-start justify-center
      row fill-height
    >
      <VFlex class="text-xs-center">
        <div v-show="logoLoaded">
          <img
            :src="logo" height="100"
            @load="logoLoaded = true"
          >
        </div>

        <p v-if="showname" class="title">
          {{ name }}
        </p>
      </VFlex>
    </VLayout>
  </VFlex>
</template>

<script>
export default {
    name: 'CompanyEntity',
    props: {
        logo: { type: String, required: true },
        name: { type: String, required: true },
        showname: { type: Boolean, default: true }
    },
    data() {
        return {
            logoLoaded: false
        }
    }
}
</script>
