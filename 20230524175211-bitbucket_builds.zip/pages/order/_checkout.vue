<template>
  <VLayout column>
    <CompanyEntity
      v-if="!checkout.remote_payment" :logo="companyLogo"
      :name="user.name"
    />
    <BPRemotePaymentHeader v-else />
    <PaymentForm
      :order-id="orderId"
      :service-api="serviceApi"
      :excluded="excludedBins"
      :envs="envs"
      :checkout="checkout"
      :user="user"
      :plans="plans"
      :permissions="permissions"
    />
    <BPFooter />
  </VLayout>
</template>

<script>
/* eslint-disable complexity */
import checkUUID from '@/utils/check-uuid.mixin'

import CompanyEntity from '@/components/shared/CompanyEntity.vue'
import PaymentForm from '@/components/project/PaymentForm.vue'
import BPFooter from '@/components/shared/BPFooter.vue'
import BPRemotePaymentHeader from '@/components/shared/BPRemotePaymentHeader.vue'

export default {
    components: {
        CompanyEntity, 
        PaymentForm,
        BPFooter,
        BPRemotePaymentHeader,
    },
    head() {
        const trustedScriptToBeInjected = process.env.C2P_SCRIPT;
        if ( this.checkout.remote_payment ) {
            return {
                title:  'Pago a distancia de Billpocket',
                meta: [
                    {
                        hid: 'description',
                        name: 'description',
                        content: 'PAD'
                    }
                ],
                script: [
                    {
                        src: trustedScriptToBeInjected,
                    }
                ]
            }
        }
        return {
            script: [
                {
                    src: trustedScriptToBeInjected,
                }
            ]
        }
    },
    async asyncData ( { params, $axios, error } ) {
        try {       
            if( checkUUID( params.checkout ) ){
                const { data } = await  $axios.get(
                    `${ process.env.PAYWITH_SERVICE }/checkout/${ params.checkout }?bpKey=${ process.env.BPKEY }` 
                );
                if( data.transaction.hasOwnProperty( 'authNumber' )   ){
                    error(  { 
                        message: `La orden ${ params.checkout } ya se encuentra pagada.`, 
                        redirectUrl: data.user.redirectUrl,
                        redirectText: 'Volver al comercio',
                    } );
                }
                return {
                    orderId: params.checkout,
                    checkout: data.checkout,
                    serviceApi: process.env.PAYWITH_SERVICE,
                    excludedBins: process.env.EXCLUDED_BINES,
                    user: data.user,
                    plans: data.plans,
                    permissions: {
                        unlimitedAmexAndBBVA: data.canProcessAnyAmexAmount,
                        unlimitedInternational: data.canProcesssInternationalCard, 
                    },
                    envs: {
                        status3dsPAD: process.env.STATUS_3DS_PAD,
                        status3dsForMerchants: process.env.STATUS_3DS_MERCHANTS,
                        LIMIT_FOR_INTERNATIONAL_CARDS: process.env.MAX_AMOUNT_INTERNATIONAL_CARDS,
                        LIMIT_MESSAGE: process.env.LIMIT_MESSAGE,
                        VUE_RECAPTCHA_KEY: process.env.VUE_RECAPTCHA_KEY,
                        SRC_APP_ID: process.env.SRC_APP_ID,
                        STATUS_C2P: process.env.STATUS_C2P,
                        siftBeaconKey: process.env.SIFT_BEACON_KEY,
                        amexMessage: process.env.LIMIT_MESSAGE,
                        amexLimit: process.env.MAX_AMOUNT_AMEX,
                        VUE_BP_RISK_ERROR: process.env.VUE_BP_RISK_ERROR,
                        VUE_BP_RISK_CODE: process.env.VUE_BP_RISK_CODE,
                        addTagManager: process.env.TAG_MANAGER === 'add',
                        c2pBrands: process.env.ALLOWED_BRAND_FOR_C2P || 'mastercard',
                        statusC2PForIntegrations: process.env.CLICK_TO_PAY_ENABLED_FOR_INTEGRATIONS === 'enabled',
                        enabledC2PForPAD: process.env.CLICK_TO_PAY_ENABLED_FOR_PAD === 'enabled',
                        statusPilotTestForC2P: ( process.env.CLICK_TO_PAY_PILOT === 'enabled' ) || false,
                        usersListC2pPilot: process.env.USERS_LIST_C2P || '',
                        c2PDynamicDataType: process.env.C2P_DYNAMIC_DATATYPE || 'NONE'
                    },
                    companyLogo: `${ process.env.LOGO_URL }/${ data.user.userId }logo.png?strict=true`
                };
            }else {
                error( { 
                    statusCode:  404, 
                    message:  'Formato de Orden invalido' ,
                } )
            }
        } catch ( err ) {
            const { response } = err;
            error( { 
                statusCode: response ?  response.status :  500, 
                message: process.env.DEFAULT_ERROR_PAYWITH, 
                callbackUrl: `/checkout/${ params.checkout }` ,
                callbackText: 'Regresar a elegir método de pago' 
            } )
        }
        
    }
}
</script>
