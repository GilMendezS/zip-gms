<template>
  <VLayout column>
    <CompanyEntity
      v-if="!checkout.remote_payment" :logo="companyLogo"
      :name="user.name"
    />
    <BPRemotePaymentHeader v-else />
    <PaymentForm
      :order-id="orderId"
      :service-api="serviceApi"
      :excluded="excludedBins"
      :envs="envs"
      :checkout="checkout"
      :user="user"
      :plans="plans"
      :permissions="permissions"
    />
    <BPFooter />
  </VLayout>
</template>

<script>
/* eslint-disable complexity */
import checkUUID from '@/utils/check-uuid.mixin'

import CompanyEntity from '@/components/shared/CompanyEntity.vue'
import PaymentForm from '@/components/project/PaymentForm.vue'
import BPFooter from '@/components/shared/BPFooter.vue'
import BPRemotePaymentHeader from '@/components/shared/BPRemotePaymentHeader.vue'

export default {
    components: {
        CompanyEntity, 
        PaymentForm,
        BPFooter,
        BPRemotePaymentHeader,
    },
    head() {
        const trustedScriptToBeInjected = process.env.C2P_SCRIPT;
        if ( this.checkout.remote_payment ) {
            return {
                title:  'Pago a distancia de Billpocket',
                meta: [
                    {
                        hid: 'description',
                        name: 'description',
                        content: 'PAD'
                    }
                ],
                script: [
                    {
                        src: trustedScriptToBeInjected,
                    }
                ]
            }
        }
        return {
            script: [
                {
                    src: trustedScriptToBeInjected,
                }
            ]
        }
    },
    async asyncData ( { params, $axios, error } ) {
        try {       
            if( checkUUID( params.order ) ){
                const { data } = await  $axios.get(
                    `${ process.env.PAYWITH_SERVICE }/checkout/${ params.order }?bpKey=${ process.env.BPKEY }` 
                );
                if( data.transaction.hasOwnProperty( 'authNumber' )   ){
                    error(  { 
                        message: `La orden ${ params.order } ya se encuentra pagada.`, 
                        redirectUrl: data.user.redirectUrl,
                        redirectText: 'Volver al comercio',
                    } );
                }
                const excludedForc2p = process.env.EXCLUDED_C2P_LIST.split( ',' ).map( uId => parseInt( uId, 10 ) );
                let validateTxnUrl = `${ process.env.PAYWITH_SERVICE }/txn/`;
                let threeDsVersionToBeUser = 1;
                const usersWith3dsv2 = process.env.THREE_DS_PILOT_USERS || '';
                const listUsersFor3dsv2 = usersWith3dsv2.split( ',' ).map( item => parseInt( item, 10 ) );
                if ( process.env.THREE_DS_PILOT_STATUS === 'released' ) {
                    validateTxnUrl = `${ process.env.PAYWITH_SERVICE_V2 }/3ds/`;
                    threeDsVersionToBeUser = 2;
                }
                else if ( process.env.THREE_DS_PILOT_STATUS === 'enabled'
                    && ( data.active3dsv2 || false )
                ) {
                    validateTxnUrl = `${ process.env.PAYWITH_SERVICE_V2 }/3ds/`;
                    threeDsVersionToBeUser = 2;
                }
                return {
                    orderId: params.order,
                    checkout: data.checkout,
                    serviceApi: process.env.PAYWITH_SERVICE,
                    excludedBins: process.env.EXCLUDED_BINES,
                    user: data.user,
                    plans: data.plans,
                    permissions: {
                        unlimitedAmexAndBBVA: data.canProcessAnyAmexAmount,
                        unlimitedInternational: data.canProcesssInternationalCard, 
                    },
                    envs: {
                        status3dsPAD: process.env.STATUS_3DS_PAD,
                        status3dsForMerchants: process.env.STATUS_3DS_MERCHANTS,
                        LIMIT_FOR_INTERNATIONAL_CARDS: process.env.MAX_AMOUNT_INTERNATIONAL_CARDS,
                        LIMIT_MESSAGE: process.env.LIMIT_MESSAGE,
                        VUE_RECAPTCHA_KEY: process.env.VUE_RECAPTCHA_KEY,
                        SRC_APP_ID: data.c2pConf ? data.c2pConf.srcDpaId : process.env.SRC_APP_ID,
                        STATUS_C2P: process.env.STATUS_C2P,
                        siftBeaconKey: process.env.SIFT_BEACON_KEY,
                        amexMessage: process.env.LIMIT_MESSAGE,
                        amexLimit: process.env.MAX_AMOUNT_AMEX,
                        VUE_BP_RISK_ERROR: process.env.VUE_BP_RISK_ERROR,
                        VUE_BP_RISK_CODE: process.env.VUE_BP_RISK_CODE,
                        addTagManager: process.env.TAG_MANAGER === 'add',
                        c2pBrands: process.env.ALLOWED_BRAND_FOR_C2P || 'mastercard',
                        statusC2PForIntegrations: process.env.CLICK_TO_PAY_ENABLED_FOR_INTEGRATIONS === 'enabled',
                        enabledC2PForPAD: process.env.CLICK_TO_PAY_ENABLED_FOR_PAD === 'enabled',
                        statusPilotTestForC2P: ( process.env.CLICK_TO_PAY_PILOT === 'enabled' ) || false,
                        usersListC2pPilot: process.env.USERS_LIST_C2P || '',
                        c2PDynamicDataType: data.c2pConf ? data.c2pConf.dynamicDataType : 'NONE',
                        dpaName: data.c2pConf ? data.c2pConf.dpaName : '',
                        dpaPresentationName: data.c2pConf ? data.c2pConf.dpaPresentationName : '',
                        threeDs2Piliot: process.env.THREE_DS_PILOT_STATUS || 'disabled',
                        threeDs2User: process.env.THREE_DS_PILOT_USERS || '',
                        validateTxnUrl,
                        threeDsVersionToBeUser,
                        showErrorsForC2P: process.env.DISPLAY_ERRORS_FOR_CERTIFICATION_C2P === 'true',
                        hideC2P: excludedForc2p.includes( data.user.userId )
                    },
                    companyLogo: `${ process.env.LOGO_URL }/${ data.user.userId }logo.png?strict=true`
                };
            }else {
                error( { 
                    statusCode:  404, 
                    message:  'Formato de Orden invalido' ,
                } )
            }
        } catch ( err ) {
            const { response } = err;
            error( { 
                statusCode: response ?  response.status :  500, 
                message: process.env.DEFAULT_ERROR_PAYWITH, 
                callbackUrl: `/checkout/${ params.order }` ,
                callbackText: 'Regresar a elegir método de pago' 
            } )
        }
        
    }
}
</script>
