<template>
  <VLayout column>
    <CompanyEntity :logo="companyLogo" :name="companyName" />
    <LoaderCard
      :color="companyColor" :total="checkoutTotal" :external-id="checkoutExternalId"
    />
    <BPFooter />
  </VLayout>
</template>

<script>
import checkUUID from '@/utils/check-uuid.mixin'

import CompanyEntity from '@/components/shared/CompanyEntity.vue'
import LoaderCard from '@/components/project/LoaderCard.vue'
import BPFooter from '@/components/shared/BPFooter.vue'

export default {
    components: {
        CompanyEntity, 
        LoaderCard,
        BPFooter,
    },
    props: {
        error: {
            type: Object,
            default: null
        }
    }, 
    // eslint-disable-next-line complexity
    async asyncData ( { params, $axios, error } ) {
        let redirectPayment = `/checkout/${ params.order }`;
        try {             
            if( checkUUID( params.order ) ){
                const { data } = await  $axios.get(
                    `${ process.env.PAYWITH_SERVICE }/checkout/${ params.order }?bpKey=${ process.env.BPKEY }` 
                );
                redirectPayment = data.checkout.remote_payment ? 
                    `/pay/${ params.order }` : 
                    `/checkout/${ params.order }`;
                if( data.data3dsV2 && 'riskManagement' in data.data3dsV2 ){
                    if( [ '3D0' ].includes( data.data3dsV2.riskManagement.IsoResponseCode ) ){
                        return {
                            companyLogo: `${ process.env.LOGO_URL }/${ data.user.userId }logo.png?strict=true`,
                            companyColor: data.user.colorEntity,
                            companyName: data.user.name,
                            orderId:  params.order,
                            checkoutTotal: data.checkout.total,
                            checkoutExternalId: data.checkout.externalId,      
                            serviceApi: process.env.PAYWITH_SERVICE,
                            serviceApiV2: process.env.PAYWITH_SERVICE_V2,                 
                        }
                    }else  error( { 
                        errorCode: data.data3dsV2.riskManagement.IsoResponseCode || '32',
                        // eslint-disable-next-line max-len
                        message: 'Tu verificación de identidad no pudo ser completada. Si el problema persiste, contacta a tu banco o intenta con otra tarjeta',
                        callbackUrl: redirectPayment ,
                        callbackText: 'Regresar a seleccionar pago' 
                    } )
                
                }
                else{
                    error( { 
                        statusCode:  400, 
                        message:  'La orden no está lista para el proceso de pago.',
                        callbackUrl: redirectPayment,
                        callbackText: 'Regresar a seleccionar pago'
                    } )
                }
            
            }else {
                error( { 
                    statusCode:  404, 
                    message:  'Formato de Orden invalido' ,
                } )
            }
        } catch ( err ) {
            error( { 
                statusCode: 500, 
                message: process.env.DEFAULT_ERROR_PAYWITH, 
                callbackUrl: redirectPayment ,
                callbackText: 'Regresar a elegir método de pago' 
            } )
        }
        
    }, 
    mounted(){
        this.requestPayment()
    },
    methods: {
        requestPayment(){
            let redirectPayment = `/checkout/${ this.orderId }`;
            setTimeout( ()=>{
                this.$axios.post( `${ this.serviceApiV2 }/3ds/process/${ this.orderId }`, {}, {
                    timeout: 0
                } )
                    .then( ( { data } )=>{
                        const txn = data.transaction;
                        if( txn.remote_payment ) {
                            redirectPayment = `/pay/${ this.orderId }`;
                        }
                        if( txn.status === 1 ){
                            window.location.href = `/success/${ this.orderId }`
                        }else{
                            if ( txn.remote_payment && txn.customPADMessage ) {
                                this.$nuxt.error( 
                                    { 
                                        errorCode:  txn.customPADMessage.code, 
                                        message: txn.customPADMessage.message,
                                        callbackUrl: redirectPayment,
                                        callbackText: 'Volver a elegir método de pago'
                                    }
                                )
                            } else { // flow for integrations
                                this.$nuxt.error( 
                                    { 
                                        errorCode: txn.txnISOCode ? txn.txnISOCode : data.statusCode, 
                                        message: txn.message,
                                        callbackUrl: redirectPayment,
                                        callbackText: 'Volver a elegir método de pago'
                                    }
                                )
                            }
                            
                        }
                    } )
                    .catch( ( err )=> {
                        this.$nuxt.error( 
                            { 
                                message: 'No se ha podido procesar tu pago, por favor vuelve a intentarlo.',
                                callbackUrl: redirectPayment,
                                callbackText: 'Volver a elegir método de pago'
                            }
                        ) } )
            }, 500 );
        }
    }
}
</script>
