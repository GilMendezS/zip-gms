<template>
  <VContainer fluid>
    <VLayout
      justify-center fill-height
      column pa-5 mb-5
      class="text-xs-center"
    >
      <VFlex mb-5>
        <img
          src="~/assets/billy_success.svg" alt="bp-logo" height="180px"
        >
      </VFlex>
      <VFlex my-2>
        <p class="display-1 blue-grey--text">
          Tu pago #{{ checkoutExternalId }} se ha procesado exitosamente
        </p>
      </VFlex>
      <VFlex my-4>
        <p class="title font-weight-regular">
          Te regresaremos automáticamente al sitio del comercio
          en 5 segundos... 
        </p>
        <p class="title font-weight-regular">
          Con número de autorización: 
          <strong>
            {{ authNumber }} 
          </strong>
          .
        </p>
        <VLayout
          row wrap align-center
          justify-center my-4 py-3
        >
          <VFlex md4 xs10>
            <VProgressLinear
              :indeterminate="true" :color="companyColor"
            />          
          </VFlex>
        </VLayout>
      </VFlex>
    </VLayout>
    <BPFooter class="mt-5" />
  </VContainer>
</template>

<script>
import checkUUID from '@/utils/check-uuid.mixin'
import BPFooter from '@/components/shared/BPFooter.vue'

export default {
    components: { BPFooter },
    async asyncData ( { params, $axios, error } ) {
        let redirectPayment = `/checkout/${ params.order }`;
        try {            
            if( checkUUID( params.order ) ){   
                /* eslint-disable-next-line  */
                const { data } = await  $axios.get( `${ process.env.PAYWITH_SERVICE }/checkout/${ params.order }?bpKey=${ process.env.BPKEY }&success=1`);
                if ( data.checkout.remote_payment ) { 
                    redirectPayment = `/pay/${ params.order }`;
                }
                if( data.transaction.hasOwnProperty( 'authNumber' )   ){
                    return {                 
                        companyColor: data.user.colorEntity,
                        companyName: data.user.name,
                        orderId: params.order,                    
                        checkoutExternalId: data.checkout.externalId,    
                        authNumber: data.transaction.authNumber,                            
                        serviceApi: process.env.PAYWITH_SERVICE,
                        redirectUrl: data.user.redirectUrl
                    }
                }else{
                
                    error( { 
                        message: 'La orden no ha sido pagada.',
                        callbackUrl: redirectPayment ,
                        callbackText: 'Regresar a procesar el pago' 
                    } )                
                }
                
            }else {
                error( { 
                    statusCode:  404, 
                    message:  'No encontramos tu orden' , 
                } )
            }
        } catch ( err ) {
            const { response } = err;
            error( { 
                statusCode: response ?  response.status :  500, 
                message: process.env.DEFAULT_ERROR_PAYWITH, 
                callbackUrl: redirectPayment,
                callbackText: 'Regresar a elegir método de pago' 
            } )
        }
        
    },
    mounted(){
        this.redirect();
    }, 
    methods: {
        redirect(){
            if( process.env.NODE_ENV !== 'production' ){
                setTimeout( () => {
                    window.location.href = this.redirectUrl
                }, 4900 );
            }
            else {
                setTimeout( () => {
                    window.location.href = this.redirectUrl
                }, 4900 );
            }
            
        }
    }
}
</script>
