#!/bin/bash
# |------------------------------------------|
# |                VERSION 3                 |
# |                NOV 2018                  |
# |               Maintainer:                |
# |     esuarez <at> billpocket <dot> com    |
# |            Generics functions            |
# |------------------------------------------|
# Assign project name to APP Variable. (lowercase)
APP="paywithssr"

MAIN_APP_DIR="/opt/bp-apps/${APP}"
APP_DIR="${MAIN_APP_DIR}/app"

source "${APP_DIR}/scripts/variables.sh"

# ======================= General Variables =======================
# Colors
RED='\033[00;31m'
GREEN='\033[00;32m'
YELLOW='\033[00;33m'
BLUE='\033[00;34m'
PURPLE='\033[00;35m'
CYAN='\033[00;36m'
LIGHTGRAY='\033[00;37m'
LRED='\033[01;31m'
LGREEN='\033[01;32m'
LYELLOW='\033[01;33m'
LBLUE='\033[01;34m'
LPURPLE='\033[01;35m'
LCYAN='\033[01;36m'
WHITE='\033[01;37m'

echo -e "${LGREEN}[*] Functions loaded ${WHITE}\n\n"	

# ======================== Functions ============================
copy_file_from_s3(){
  aws s3 cp "s3://billpocket-aws-configs-${VERSION}/${S3_NAME}/${1}" "${2}"
}

copy_dir_from_s3(){
  aws s3 cp "s3://billpocket-aws-configs-${VERSION}/${S3_NAME}/${1}" "${2}" --recursive
}

copy_docker_file(){
	cp -ru "${APP_DIR}/docker-compose.yml" "${MAIN_APP_DIR}/docker-compose.yml" 
}

check_if_local_exist(){
  if  [ ! -f "${2}/${1}" ]; then
    	copy_file_from_s3 "${1}" "${2}"
		echo -e "${BLUE}[*] ${1} added\n${WHITE}"	
	fi		
}

set_tunnels_permissions () {
	declare -a FILES=$(ls "${MAIN_APP_DIR}/config/bp-keys")
	for f in $FILES;
	do		
		docker exec -i "${APP}_pm2_1" chmod 400 "/opt/bp-keys/${f}"
        echo -e "${BLUE}[*] Set permissions for ${f}!${WHITE}\n "
	done
	docker exec -i "${APP}_pm2_1" chmod +x /opt/bp-scripts/bin/ -R
}

set_keys_permissions () {
	declare -a FILES=$(ls "${APP_DIR}/keys")
	for f in $FILES;
	do		
		docker exec -i "${APP}_pm2_1" chmod 400 "/app/keys/${f}"
        echo -e "${LGREEN}[*] Set permissions for ${f}!${WHITE}\n "
	done
}


check_docker_state(){
	if [  "$(docker ps -a | grep ${APP})" ]; then
		echo -e "${LPURPLE}[*] ${APP} Working!${WHITE}\n\n\n "	
	else
		echo -e "${RED}[x] ${APP} ERROR !${WHITE}\n\n\n"
	fi
}

seek_and_destroy(){
	if  [ -d "${1}" ]; then
		rm -rf "${1}"	
		echo -e "[*] Bye bye ${1} directory\n"	
	fi	
}

create_if_not_exist(){
	if  [ ! -d "${1}" ]; then
		mkdir -p "${1}"	
		echo -e "[*] ${1} directory created\n"	
	fi		
}

echo -e "${BLUE} [*] Loading Functions File ${WHITE} \n\n"
