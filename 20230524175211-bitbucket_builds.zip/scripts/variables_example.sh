#!/bin/bash
# |------------------------------------------|
# |                VERSION 3                 |
# |                NOV 2018                  |
# |               Maintainer:                |
# |     esuarez <at> billpocket <dot> com    |
# |            Project Variables             |
# |------------------------------------------|

# ======================== Project Variables ============================

# Assign project name to APP Variable. (lowercase)
APP="PROJECT_NAME"

# S3 variables (IMPORTANT)
S3_NAME="S3_DIR_APP_NAME"
VAR_APP_NAME="APP_GROUP_NAME"

if [ "$DEPLOYMENT_GROUP_NAME" == "${VAR_APP_NAME}_TEST_DeploymentGroup" ]
then
  VERSION="develop"
  SYSTEM_USER="deployer"
fi

if [ "$DEPLOYMENT_GROUP_NAME" == "${VAR_APP_NAME}_STAGING_DeploymentGroup" ]
then
  VERSION="staging"
  SYSTEM_USER="staging-deployer"
fi

if [ "$DEPLOYMENT_GROUP_NAME" == "${VAR_APP_NAME}_PROD_DeploymentGroup" ]
then
  VERSION="production"
  SYSTEM_USER="production-deployer"
fi 

echo -e "${BLUE} [*] Loading Variables File ${WHITE} \n\n"
