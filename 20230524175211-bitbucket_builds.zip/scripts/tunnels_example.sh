
#!/bin/bash
# ======================== Project logic ============================
# rename this file to tunnels.sh to be loaded on deploy process
APP="PROJECT_NAME"

MAIN_APP_DIR="/opt/bp-apps/${APP}"
APP_DIR="${MAIN_APP_DIR}/app"

source "${APP_DIR}/scripts/functions.sh"

echo -e "${CYAN}[*] - - - - - - - PROJECT LOGIC - - - - - - -${WHITE}\n\n"
# go to main directory
cd "${MAIN_APP_DIR}"

# - - - - - for systems with tunnels - - - - -
# download everytime
copy_dir_from_s3 "bp-keys/" "${MAIN_APP_DIR}/config/bp-keys/"
copy_dir_from_s3 "tunnels/" "${MAIN_APP_DIR}/config/tunnels/"
copy_file_from_s3 "supervisord.conf" "${MAIN_APP_DIR}/config/supervisord.conf"

# run Docker
docker-compose -f "${MAIN_APP_DIR}/docker-compose.yml" -p "${APP}" up --remove-orphans -d  --force-recreate

# set permissions on tunnels scripts and keys
set_tunnels_permissions

# - - - - - end for systems with tunnels - - - - -