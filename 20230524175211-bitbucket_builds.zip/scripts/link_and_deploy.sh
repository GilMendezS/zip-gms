#!/bin/bash
# |------------------------------------------|
# |                VERSION 3                 |
# |                NOV 2018                  |
# |               Maintainer:                |
# |     esuarez <at> billpocket <dot> com    |
# |        Deploy for NODE with pm2          |
# |------------------------------------------|
# Assign project name to APP Variable. (lowercase)
APP="paywithssr"

MAIN_APP_DIR="/opt/bp-apps/${APP}"
APP_DIR="${MAIN_APP_DIR}/app"

source "${APP_DIR}/scripts/functions.sh"

echo -e "${CYAN} [*] Running on ${VERSION} version ${WHITE} \n\n"

# ======================== Action! ============================
create_if_not_exist "${MAIN_APP_DIR}/logs"
create_if_not_exist "${MAIN_APP_DIR}/config"

# download everytime
copy_file_from_s3 "ecosystem.config.js" "${MAIN_APP_DIR}/config/ecosystem.config.js"
copy_file_from_s3 "entrypoint-ssr.sh" "${MAIN_APP_DIR}/config/entrypoint-ssr.sh"
copy_file_from_s3 "docker-compose.yml" "${MAIN_APP_DIR}/docker-compose.yml"

# new owner is System user
chown ${SYSTEM_USER}:${SYSTEM_USER} "${MAIN_APP_DIR}" -R

# change user 
su --login ${SYSTEM_USER}

# activate nvm
source "/home/${SYSTEM_USER}/.nvm/nvm.sh"

# go to working directory
cd "${APP_DIR}"

# check if yarn exist 
npm -g i yarn

# Install dependencies on parent directory for reuse it
yarn install

# if tunnels exist, load the file
if [ -f "${APP_DIR}/scripts/tunnels.sh" ]; then 
    source "${APP_DIR}/scripts/tunnels.sh"
fi

# if project logic exist, load the file
if [ -f "${APP_DIR}/scripts/project_logic.sh" ]; then 
    source "${APP_DIR}/scripts/project_logic.sh"
fi

# go to main directory
cd "${MAIN_APP_DIR}"

# run Docker
docker-compose -f "${MAIN_APP_DIR}/docker-compose.yml" -p "${APP}" up --remove-orphans -d  --force-recreate

# just check if docker still alive
check_docker_state
