#!/bin/bash
# |------------------------------------------|
# |                VERSION 3                 |
# |                NOV 2018                  |
# |               Maintainer:                |
# |     esuarez <at> billpocket <dot> com    |
# |            Generics functions            |
# |------------------------------------------|

# ======================== Project logic ============================
# rename this file to project_logic.sh to be loaded on deploy process
APP="paywithssr"

MAIN_APP_DIR="/opt/bp-apps/${APP}"
APP_DIR="${MAIN_APP_DIR}/app"

source "${APP_DIR}/scripts/functions.sh"

echo -e "${CYAN}[*] - - - - - - - PROJECT LOGIC - - - - - - -${WHITE}\n\n"

yarn build 

echo -e "${CYAN}[*] - - - - - - - PROJECT LOGIC END - - - - - - -${WHITE}\n\n"