#!/bin/bash
# ======================== Project logic ============================
# rename this file to project_logic.sh to be loaded on deploy process
APP="PROJECT_NAME"

MAIN_APP_DIR="/opt/bp-apps/${APP}"
APP_DIR="${MAIN_APP_DIR}/app"

source "${APP_DIR}/scripts/functions.sh"

echo -e "${CYAN}[*] - - - - - - - PROJECT LOGIC - - - - - - -${WHITE}\n\n"
