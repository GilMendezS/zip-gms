# CI Scripts Node Version

## Adapte estos scripts a su proyecto

Para funcionar correctamente, es necesario crear un archivo ```variables.sh``` a partir de ```variables_example.sh```.

Si el proyecto requiere de alguna lógica extra, puede crear un archivo ```project_logic.sh``` basado en ```project_logic_example.sh```. 

De igual manera si necesita de algún archivo "hide" ```.eslintrc``` por ejemplo. Es necesario que lo ponga en un directorio ```hidden_files```en el root del proyecto, esto debido a limitaciones de code deploy. 
Ejemplo ```./hidden_files/eslintrc```  el cual al momento del deploy será colocado en:  ```./.eslintrc```.

## Importante

No olvide poner el nombre de su aplicación en las variables "```APP```" de cada archivo, para su funcionamiento. Si no conoce el nombre de alguna variable como ```S3_NAME```, contacte con el compañero a cargo de la infraestructura.
