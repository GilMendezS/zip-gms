import isUUID from 'validator/lib/isUUID';

export default ( value )=> isUUID( value ,4 );
