/* eslint-disable max-len */
export default class Click2PayBP {
    constructor( srcId ) {
        this.srcId = srcId;
    }
    async getInstance() {
        // eslint-disable-next-line no-undef
        const click2payInstance = new Click2Pay();
        const conf = this.getDefaultConf();
        conf.srcDpaId = this.srcId;
        await click2payInstance.init( conf )
    }
    getDefaultConf( amount, brands, c2PDynamicDataType = 'NONE', dpaData = {}, confirmPayment = false ) {
        return {
            srcDpaId: '',
            cardBrands: brands,
            dpaTransactionOptions: {
                transactionAmount: {
                    transactionAmount: parseFloat( amount ),
                    transactionCurrencyCode: 'MXN'
                },
                dpaLocale: 'es_MX',
                consumerEmailAddressRequested: true,
                consumerPhoneNumberRequested: true,
                dpaAcceptedBillingCountries: [],
                dpaAcceptedShippingCountries: [],
                dpaBillingPreference: 'NONE',
                paymentOptions: [
                    {
                        dynamicDataType: c2PDynamicDataType,
                    }
                ],
                confirmPayment,
                customInputData: {
                    'com.mastercard.dcfExperience': 'WITHIN_CHECKOUT'
                },
            },
            dpaData,
        };
    }
    getFakeChannelsForOTP() {
        return {
            'maskedValidationChannel': '+91(***) ***-*460',
            'supportedValidationChannels': [
                {
                    'identityProvider': 'SRC',
                    'maskedValidationChannel': 'j*****e@moofwd.com',
                    'identityType': 'EMAIL',
                    'validationChannelId': 'EMAIL'
                },
                {
                    'identityProvider': 'SRC',
                    'maskedValidationChannel': '+91(***) ***-*460',
                    'identityType': 'SMS',
                    'validationChannelId': 'SMS'
                }
            ],
            'network': 'mastercard'
        };
    }
    getFakeOtpValidation() {
        return [
            {
                'srcDigitalCardId': '8d070e67-8503-4260-8f7f-ed574e36d9c6',
                'srcPaymentCardId': null,
                'panBin': '520473',
                'panLastFour': '8931',
                'tokenLastFour': '5206',
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'MasterCard Test Bank',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/d5397362-33d1-468b-81e6-b5eeb5693972.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '05',
                'panExpirationYear': '2024',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-08-26T09:33:50.189Z',
                'dateOfCardLastUsed': '2021-08-26T13:42:40.576Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': null,
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '07097',
                    'addressId': 'c0e11e29-5fa6-416c-9dbb-3c4b9128518b'
                }
            },
            {
                'srcDigitalCardId': '361a8d27-0b74-413d-a318-db5dc568e908',
                'srcPaymentCardId': null,
                'panBin': '520473',
                'panLastFour': '4601',
                'tokenLastFour': '4750',
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'MasterCard Test Bank',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/bf15485f-83ee-4dee-a38e-a5e67b373006.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '02',
                'panExpirationYear': '2023',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-08-16T08:29:34.069Z',
                'dateOfCardLastUsed': '2021-08-26T13:05:09.217Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': 'N** J*****',
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '07096',
                    'addressId': 'deffff7f-6f9e-4b66-b42a-01a81c0aa35b'
                }
            },
            {
                'srcDigitalCardId': 'e79cc8fe-7fa9-4a44-8b87-2be58f317e98',
                'srcPaymentCardId': null,
                'panBin': '518600',
                'panLastFour': '9726',
                'tokenLastFour': null,
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'Mastercard',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/HIGH-MASK-3x.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '12',
                'panExpirationYear': '2024',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-08-23T10:38:36.648Z',
                'dateOfCardLastUsed': '2021-08-25T12:15:33.917Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': null,
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '40086',
                    'addressId': 'd3d8918a-2990-4355-8b20-d8a9a02e696b'
                }
            },
            {
                'srcDigitalCardId': 'c29b8fa0-0b25-4c24-8d91-3d3495eb2b43',
                'srcPaymentCardId': null,
                'panBin': '518600',
                'panLastFour': '9726',
                'tokenLastFour': null,
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'Mastercard',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/HIGH-MASK-3x.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '05',
                'panExpirationYear': '2025',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-08-24T09:21:56.072Z',
                'dateOfCardLastUsed': '2021-08-25T12:08:52.904Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': null,
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '07001',
                    'addressId': 'd7b90cbf-b6fb-47d4-a1a9-9767859901f7'
                }
            },
            {
                'srcDigitalCardId': '9e718420-ce93-41b8-9413-e8270d0ff986',
                'srcPaymentCardId': null,
                'panBin': '555555',
                'panLastFour': '4444',
                'tokenLastFour': null,
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'Mastercard',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/HIGH-MASK-3x.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '02',
                'panExpirationYear': '2023',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-07-15T16:32:24.883Z',
                'dateOfCardLastUsed': '2021-08-16T07:42:05.485Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': 'N** J*****',
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '07008',
                    'addressId': '99310422-7a5c-4527-b5b3-263128354564'
                }
            }
        ]
          
    }
    getFakeCards() {
        return [
            {
                'srcDigitalCardId': '8d070e67-8503-4260-8f7f-ed574e36d9c6',
                'srcPaymentCardId': null,
                'panBin': '520473',
                'panLastFour': '8931',
                'tokenLastFour': '5206',
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'MasterCard Test Bank',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/d5397362-33d1-468b-81e6-b5eeb5693972.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '05',
                'panExpirationYear': '2024',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-08-26T09:33:50.189Z',
                'dateOfCardLastUsed': '2021-08-26T13:42:40.576Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': null,
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '07097',
                    'addressId': 'c0e11e29-5fa6-416c-9dbb-3c4b9128518b'
                }
            },
            {
                'srcDigitalCardId': '361a8d27-0b74-413d-a318-db5dc568e908',
                'srcPaymentCardId': null,
                'panBin': '520473',
                'panLastFour': '4601',
                'tokenLastFour': '4750',
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'MasterCard Test Bank',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/bf15485f-83ee-4dee-a38e-a5e67b373006.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '02',
                'panExpirationYear': '2023',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-08-16T08:29:34.069Z',
                'dateOfCardLastUsed': '2021-08-26T13:05:09.217Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': 'N** J*****',
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '07096',
                    'addressId': 'deffff7f-6f9e-4b66-b42a-01a81c0aa35b'
                }
            },
            {
                'srcDigitalCardId': 'e79cc8fe-7fa9-4a44-8b87-2be58f317e98',
                'srcPaymentCardId': null,
                'panBin': '518600',
                'panLastFour': '9726',
                'tokenLastFour': null,
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'Mastercard',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/HIGH-MASK-3x.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '12',
                'panExpirationYear': '2024',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-08-23T10:38:36.648Z',
                'dateOfCardLastUsed': '2021-08-25T12:15:33.917Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': null,
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '40086',
                    'addressId': 'd3d8918a-2990-4355-8b20-d8a9a02e696b'
                }
            },
            {
                'srcDigitalCardId': 'c29b8fa0-0b25-4c24-8d91-3d3495eb2b43',
                'srcPaymentCardId': null,
                'panBin': '518600',
                'panLastFour': '9726',
                'tokenLastFour': null,
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'Mastercard',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/HIGH-MASK-3x.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '05',
                'panExpirationYear': '2025',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-08-24T09:21:56.072Z',
                'dateOfCardLastUsed': '2021-08-25T12:08:52.904Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': null,
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '07001',
                    'addressId': 'd7b90cbf-b6fb-47d4-a1a9-9767859901f7'
                }
            },
            {
                'srcDigitalCardId': '9e718420-ce93-41b8-9413-e8270d0ff986',
                'srcPaymentCardId': null,
                'panBin': '555555',
                'panLastFour': '4444',
                'tokenLastFour': null,
                'digitalCardData': {
                    'status': 'ACTIVE',
                    'presentationName': '',
                    'descriptorName': 'Mastercard',
                    'artUri': 'https://sbx.assets.mastercard.com/card-art/combined-image-asset/HIGH-MASK-3x.png',
                    'artHeight': null,
                    'artWidth': null,
                    'pendingEvents': null,
                    'coBrandedName': null,
                    'isCoBranded': false
                },
                'digitalCardFeatures': [],
                'panExpirationMonth': '02',
                'panExpirationYear': '2023',
                'digitalCardRelatedData': null,
                'countryCode': 'US',
                'dcf': {
                    'type': 'BROWSER',
                    'uri': 'https://sandbox.src.mastercard.com/pay/',
                    'logoUri': 'http://mastercard.com/',
                    'name': 'mastercard'
                },
                'dateOfCardCreated': '2021-07-15T16:32:24.883Z',
                'dateOfCardLastUsed': '2021-08-16T07:42:05.485Z',
                'paymentCardDescriptor': 'mastercard',
                'tokenBinRange': null,
                'maskedBillingAddress': {
                    'name': 'Jo** **e',
                    'line1': 'N** J*****',
                    'line2': 'N** J*****',
                    'line3': null,
                    'city': 'New Jersey',
                    'state': 'NJ',
                    'countryCode': 'US',
                    'zip': '07008',
                    'addressId': '99310422-7a5c-4527-b5b3-263128354564'
                }
            }
        ]          
    }
    getFakeCheckout() {
        // return {
        //     'checkoutActionCode': 'COMPLETE',
        //     'checkoutResponse': 'eyJpc3MiOiJodHRwczpcL1wvbWFzdGVyY2FyZC5jb20iLCJpYXQiOjE2MzAzMDY1NTEsImFsZyI6IlJTMjU2IiwianRpIjoiZjQzYjgwZmMtOTdmOS00MWU0LWJkMmQtOGY2ZDY4NzM0OWY4Iiwia2lkIjoiMTQ5MTI2LXNyYy1wYXlsb2FkLXZlcmlmaWNhdGlvbiJ9.eyJzcmNDb3JyZWxhdGlvbklkIjoiMzRmNGEwNGIuNWVlNmI0OWYtMjBlOC00MzhlLTllODktNTlhODM3ZmNjNmM3Iiwic3JjaVRyYW5zYWN0aW9uSWQiOiIzNTAzMjA5My02MTViLTQ0NjktYjY3Zi0xMjBhMWYwYjRiOGIiLCJtYXNrZWRDYXJkIjp7InNyY0RpZ2l0YWxDYXJkSWQiOiIzNjFhOGQyNy0wYjc0LTQxM2QtYTMxOC1kYjVkYzU2OGU5MDgiLCJwYW5CaW4iOiI1MjA0NzMiLCJwYW5MYXN0Rm91ciI6IjQ2MDEiLCJ0b2tlbkxhc3RGb3VyIjoiNDc1MCIsImRpZ2l0YWxDYXJkRGF0YSI6eyJzdGF0dXMiOiJBQ1RJVkUiLCJwcmVzZW50YXRpb25OYW1lIjoiVGVzdCBJc3N1ZXLCriIsImRlc2NyaXB0b3JOYW1lIjoibWFzdGVyY2FyZCIsImFydFVyaSI6Imh0dHBzOi8vc2J4LmFzc2V0cy5tYXN0ZXJjYXJkLmNvbS9jYXJkLWFydC9jb21iaW5lZC1pbWFnZS1hc3NldC9iZjE1NDg1Zi04M2VlLTRkZWUtYTM4ZS1hNWU2N2IzNzMwMDYucG5nIiwiaXNDb0JyYW5kZWQiOmZhbHNlfSwicGFuRXhwaXJhdGlvbk1vbnRoIjoiMDIiLCJwYW5FeHBpcmF0aW9uWWVhciI6IjIwMjMiLCJwYXltZW50Q2FyZFR5cGUiOiJDUkVESVQiLCJtYXNrZWRCaWxsaW5nQWRkcmVzcyI6eyJhZGRyZXNzSWQiOiJkZWZmZmY3Zi02ZjllLTRiNjYtYjQyYS0wMWE4MWMwYWEzNWIiLCJuYW1lIjoiUHIqKioqKnQgUGEqKip5IiwibGluZTEiOiJOKiogSioqKioqIiwibGluZTIiOiJOKiogSioqKioqIiwiY2l0eSI6Ik5ldyBKZXJzZXkiLCJzdGF0ZSI6Ik5KIiwiY291bnRyeUNvZGUiOiJVUyIsInppcCI6IjA3MDk2In0sImRhdGVPZkNhcmRDcmVhdGVkIjoiMjAyMS0wOC0xNlQwODoyOTozNC4wNjlaIiwiZGF0ZU9mQ2FyZExhc3RVc2VkIjoiMjAyMS0wOC0zMFQwNjo0Nzo0Mi45MjdaIn0sIm1hc2tlZENvbnN1bWVyIjp7InNyY0NvbnN1bWVySWQiOiI0ZjA5OWEyZi00NmE4LTQ5ZTMtOGYxMy1lY2E3NTMzM2MzOTQiLCJtYXNrZWRDb25zdW1lcklkZW50aXR5Ijp7ImlkZW50aXR5UHJvdmlkZXIiOiJTUkMiLCJpZGVudGl0eVR5cGUiOiJFTUFJTF9BRERSRVNTIn0sIm1hc2tlZEVtYWlsQWRkcmVzcyI6InAqKioqKnBAbW9vZndkLmNvbSIsIm1hc2tlZE1vYmlsZU51bWJlciI6eyJjb3VudHJ5Q29kZSI6IjkxIiwicGhvbmVOdW1iZXIiOiIoKioqKSAqKiotKjQ2MCJ9LCJjb3VudHJ5Q29kZSI6IkdCIiwibGFuZ3VhZ2VDb2RlIjoiZW4iLCJzdGF0dXMiOiJBQ1RJVkUiLCJtYXNrZWRGaXJzdE5hbWUiOiJQKioqKioqKiIsIm1hc2tlZExhc3ROYW1lIjoiUCoqKioqIiwibWFza2VkRnVsbE5hbWUiOiJQKioqKioqKiBQKioqKioiLCJkYXRlQ29uc3VtZXJBZGRlZCI6IjIwMjEtMDctMTVUMTY6MzM6NTAuNzc1WiIsImRhdGVDb25zdW1lckxhc3RVc2VkIjoiMjAyMS0wOC0zMFQwNjo1NToxOS4zMTJaIn19.IRYOlxqv4abs8SmiJl1v_7_OPgVbslpXNCshjUBTfofDSWlGmRm7pJZGnXqfosxsLv9i5KcKXiskh2s-lokUKII5WNTcVlM1o9pbXlMD7Um0cOtu4BcqLHp4_JBb19EL-oC8qst5sdHuRy9mYaJ51cutYO5nGrnkzPH9BorXOfkloZapI7sdexJEMjhO94qzKEM7aBSduMoJf6kmgoxZL85wOFzBilqMG5Bc23IiIG4hb-NdA6JnC3LDoAD-t7-V0HUyHNGkI9_KGbX2RCZOU4naENkxXKq5wxdBL4mUT6ioqkFvLl3o-4V4FTkbhf666yA06-kMJCmReYpsVYejFg',
        //     'idToken': 'eyJraWQiOiIxNDkxMjUtc3JjLWlkZW50aXR5LXZlcmlmaWNhdGlvbiIsInR5cCI6IkpXVCtleHQuaWRfdG9rZW4iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI0ZjA5OWEyZi00NmE4LTQ5ZTMtOGYxMy1lY2E3NTMzM2MzOTQiLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImFtciI6WyJzbXNfb3RwIl0sImlzcyI6Imh0dHBzOlwvXC9tYXN0ZXJjYXJkLmNvbSIsInNyY19lbWFpbF9tYXNrIjoicCoqKioqcEBtb29md2QuY29tIiwicGhvbmVfbnVtYmVyX3ZlcmlmaWVkIjp0cnVlLCJzcmNfcGhvbmVfbnVtYmVyX21hc2siOiIoKioqKSAqKiotKjQ2MCIsImF1ZCI6WyJodHRwczpcL1wvbWFzdGVyY2FyZC5jb20iLCJodHRwczpcL1wvd3d3LnZpc2EuY29tIiwiaHR0cHM6XC9cL2FtZXJpY2FuZXhwcmVzcy5jb20iLCJodHRwczpcL1wvc3JjLmRpc2NvdmVyLmNvbSJdLCJhdXRoX3RpbWUiOjE2MzAzMDY1MTgsInBob25lX251bWJlciI6ImVnUUp3MWRsN0M3Q2hLRlExZ0ZHVE9ja0RUWno4dXZrYStaZUFaeWtRRlk9IiwiZXhwIjoxNjMwMzA3NDE5LCJpYXQiOjE2MzAzMDY1MTksImp0aSI6IjdiYjk3ODAyLTZkMWItNDc2ZC1iZWYwLTk1YTUyOWVmMzhjOCIsImVtYWlsIjoiY0laMEJOYmZud2R5bDhBc3VCdHJtVUtwMWFCa0ZlNXRneEFOK25mbDdJUT0ifQ.N33L90u3oIU9mgsLkDX46TFQQSr-NPFjf7rkbVblvBX2vrWJvA7scNlvGFTOeOHenowHmlw8IqOv89ZPlJh9hgUOXeEJEvjZXkDJKSyeI0KAmM6i-L-3vXkW5JkND-II0PjIzcMBinm2UvsthauTsjOfg1Ro4–qQVdO-W553pCpS775VE5rqTqkfIovQDnkC6h4Lg8L04OIegsAfusGzbu3blQrhvBHrGEQn7-KrrsdjtrhcCxMezNBfiwTURs1YUYUPWeDshBFFk2Iox604JKL23UUoVceAre5M57u22NW5e5HiTAFs306Pg0qv1Lwakwt5CrOMiHTqN5u4l3_Tw',
        //     'network': 'mastercard',
        //     'headers': {
        //         'merchant-transaction-id': '0a4e0d3.34f4a04b.484390fe23fa6378e6039fbf914958ae9e1ff98f',
        //         'x-src-cx-flow-id': '34f4a04b.5ee6b49f-20e8-438e-9e89-59a837fcc6c7.1630307453'
        //     }
        // };
        return {
            'checkoutActionCode': 'ERROR',
            'headers': {
                'merchant-transaction-id': '0a4e0d3.34f4a04b.894125b16ddd1f1b3a58273d63a0894179ac3535',
                'x-src-cx-flow-id': '34f4a04b.5ab95e32-30f7-483f-846f-a08230a6d2ed.1618397078'
            },
            'idToken': 'eyJraWQiOiIxNTExNjQtc3JjLWlkZW50aXR5LXZlcmlmaWNhdGlvbiIsInR5cCI6IkpXVCtleHQuaWRfdG9rZW4iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI4YWY3YTM4OC1lMzcxLTRlOGEtYWUzYS1jNTcxYTI1NGRmN2EiLCJlbWFpbF92ZXJpZmllZCI6ZmFsc2UsImFtciI6WyJzbXNfb3RwIl0sImlzcyI6Imh0dHBzOlwvXC9tYXN0ZXJjYXJkLmNvbSIsInNyY19lbWFpbF9tYXNrIjoiaioqKioqYUBtYWlsaW5hdG9yLmNvbSIsInBob25lX251bWJlcl92ZXJpZmllZCI6dHJ1ZSwic3JjX3Bob25lX251bWJlcl9tYXNrIjoiKCoqKikgKioqLSoyMzQiLCJhdWQiOlsiaHR0cHM6XC9cL21hc3RlcmNhcmQuY29tIiwiaHR0cHM6XC9cL3d3dy52aXNhLmNvbSIsImh0dHBzOlwvXC9hbWVyaWNhbmV4cHJlc3MuY29tIiwiaHR0cHM6XC9cL21hc3RlcnBhc3N0ZXN0c3RvcmUuY29tIl0sImF1dGhfdGltZSI6MTYxODM5NjE2OCwicGhvbmVfbnVtYmVyIjoicEM2S3hjbEhsVnN4a1I1NHJ0T1dlajJXNEpYa1wvQUhvcGUzQzRBdTNrSUU9IiwiZXhwIjoxNjE4Mzk3MDY4LCJpYXQiOjE2MTgzOTYxNjgsImp0aSI6IjlhMDg5OTY5LTZhYjctNDYzMS04ZGM1LTM5YjE4YWNmYmVhMSIsImVtYWlsIjoiXC9qb2dnNUZBM21JYkxkanltMnRaTEJlRTZiZU5Pd0VQdWFWb0lcL3J1cWhJPSJ9.iO6mLE2Tl8HKN2A2-ayMN7NcTbTC2G11ReezU9huN_HmS9A3ynO06UnG-O7jfjZUktCxj42jTHQoYAJJ3tjHCpA11zgwGx37vDbcJsQB1peLvy-aQDQDQcWulUZCNmp9EepO_K6k0esLisCyyS-SvA1wttE4u7S2FPycwrOIZKY6-75aQLB1904EW-oxoc0PKq-XJe6KPylhrGiqyRbxlaR3_OAfkEzKG5b2_5-HLodgYbbZm2B4z9eKMKESv58uHh3J0m63OYbu2YnonkjU-mBhxIvoDX6MkMa1cCLErnhu1Ge3BEIrwu61HvT6j9ja-sLRXcbsx0O28e_1bfJGRA'
        }
    }
}