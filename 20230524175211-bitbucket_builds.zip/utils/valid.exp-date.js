const MONTH_ERROR = 'El mes de vencimiento es invalido.'
const MONTH_PAST_ERROR = 'La tarjeta ya se encuentra vencida.'
const YEAR_ERROR = 'El año de vencimiento es invalido.'
export default ( value )=>{
    if( !value ) return '';
    if( value.length < 4 ) return '';
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;
    const month = value.substring( 0,2 );
    const year = value.substring( 2,4 );
    
    if( `20${ year }` === `${ currentYear }`  && month < currentMonth ) return MONTH_PAST_ERROR;

    if( month > '12' || month <= 0 ) return MONTH_ERROR;

    if( `20${ year }` < currentYear ) return YEAR_ERROR;

    return false;
};