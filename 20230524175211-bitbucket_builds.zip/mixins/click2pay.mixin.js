/* eslint-disable no-unreachable */
/* eslint-disable no-undef */
import Click2PayBP from '../utils/click2pay';
const defaultBrands = [ 'mastercard', 'visa', 'amex' ];
export default {
    data: () => ( {

    } ),
    methods: {
        async initializeClick2Pay( srcAppId, cards = [] ) {
            try {
                const c2pBp = new Click2PayBP( srcAppId );
                return c2pBp.getInstance();
            } catch ( error ) {
                return null;
            }
        },
        async getCards ( srcAppId, brands = [] ) {
            try {
                const click2payInstance = new Click2Pay()
                await click2payInstance.init( {
                    srcDpaId: srcAppId,
                    cardBrands: brands || defaultBrands,
                    dpaTransactionOptions: {
                        dpaLocale: 'es_MX',
                        consumerEmailAddressRequested: true,
                        consumerPhoneNumberRequested: true,
                        dpaAcceptedBillingCountries: [],
                        dpaAcceptedShippingCountries: [],
                        dpaShippingPreference: 'NONE',
                        dpaBillingPreference: 'NONE',
                        consumerNameRequested: true,
                    },
                    dpaData: {
                        dpaPresentationName: 'Billpocket',
                        dpaName: 'POCKET DE LATINOAMERICA S.A.P.I. de C.V.',
                    }
                } )
                return click2payInstance.getCards();
            } catch ( error ) {
                return null;
            }
        },
        async validateOTPInput( srcAppId, brands = [], value = '' ) {
            try {
                const click2payInstance = new Click2Pay()
                await click2payInstance.init( {
                    srcDpaId: srcAppId,
                    cardBrands: brands || defaultBrands,
                    dpaTransactionOptions: {
                        dpaLocale: 'es_MX',
                        consumerEmailAddressRequested: true,
                        consumerPhoneNumberRequested: true,
                        dpaAcceptedBillingCountries: [],
                        dpaAcceptedShippingCountries: [],
                        dpaBillingPreference: 'FULL',
                        customInputData: {
                            'com.mastercard.dcfExperience': 'WITHIN_CHECKOUT'
                        },
                        paymentOptions: [
                            {
                                dpaDynamicDataTtlMinutes: 15,
                                dynamicDataType: 'CARD_APPLICATION_CRYPTOGRAM_SHORT_FORM',
                            }
                        ],
                    },
                    dpaData: {
                        dpaPresentationName: 'Billpocket',
                        dpaName: 'POCKET DE LATINOAMERICA S.A.P.I. de C.V.',
                    }
                } )
                return click2payInstance.validate( {
                    value,
                } );               
            } catch ( error ) {
                return null;
            }
        },
    }
}
