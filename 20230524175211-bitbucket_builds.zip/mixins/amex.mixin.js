export default {
    methods: {
        setAsAmexCard( isAmex ){
            if ( isAmex ) {
                this.cvvDigits = '####';
                this.placeholderDigits = '****';
                this.cardDigits = '#### - ###### - #####';
                this.placeholderCard = 'xxxx - xxxxxx - xxxxx';
            } else {
                this.cvvDigits = '###';
                this.placeholderDigits = '***';
                this.cardDigits = '#### - #### - #### - ####';
                this.placeholderCard = 'xxxx - xxxx - xxxx - xxxx';
            }
        },
    }
}