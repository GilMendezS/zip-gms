export default {
    methods: {
        fixedDigits( value ){
            if( value ) {
                return value.toString().replace( /\B(?=(\d{3})+(?!\d))/g, ',' );
            }
            return '';
        },
    }
}